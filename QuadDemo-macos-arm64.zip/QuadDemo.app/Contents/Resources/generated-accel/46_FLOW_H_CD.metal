#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template <typename ImageT>
void spvImageFence(ImageT img) { img.fence(); }

struct _466
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float2 _m5;
    float4 _m6[2];
    int _m7;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _466& _468 [[buffer(7)]], texture2d<float> _40 [[texture(2)]], texture2d<float> _47 [[texture(3)]], texture2d<float> _53 [[texture(4)]], texture2d<float, access::read_write> _192 [[texture(5)]], texture2d<float, access::write> _571 [[texture(6)]], sampler _40Smplr [[sampler(2)]], sampler _47Smplr [[sampler(3)]], sampler _53Smplr [[sampler(4)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _461 = int2(gl_GlobalInvocationID.xy);
        bool _473 = _461.x >= int(_468._m0.x);
        bool _483;
        if (!_473)
        {
            _483 = _461.y >= int(_468._m0.y);
        }
        else
        {
            _483 = _473;
        }
        if (_483)
        {
            break;
        }
        float2 _495 = (float2(_461) + float2(0.5)) / _468._m0;
        float2 _500 = float2(1.0) / _468._m1;
        float4 _1374;
        do
        {
            int2 _640 = int2(_495 * _468._m1);
            if (_468._m7 == 0)
            {
                spvImageFence(_192);
                _1374 = _192.read(uint2(_640));
                break;
            }
            float2 _654 = _53.sample(_53Smplr, ((floor(_495 * _468._m5) + float2(0.5)) / _468._m5), level(0.0)).xy * 2.0;
            float2 _656 = _654 * _500;
            int _1311;
            float _1312;
            float _1313;
            _1313 = 1.0;
            _1312 = 0.0;
            _1311 = -1;
            float _1372;
            float _1373;
            for (; _1311 <= 1; _1313 = _1372, _1312 = _1373, _1311++)
            {
                _1373 = _1312;
                _1372 = _1313;
                for (int _1370 = -1; _1370 <= 1; )
                {
                    float4 _899 = _40.sample(_40Smplr, (_495 + (float2(float(_1370), float(_1311)) * _500)), level(0.0));
                    float _877 = _899.x;
                    _1373 = fast::max(_1373, _877);
                    _1372 = fast::min(_1372, _877);
                    _1370++;
                    continue;
                }
            }
            if ((_1312 - _1313) < 0.0)
            {
                float4 _666 = float4(_654, 0.0, 0.0);
                _192.write(_666, uint2(_640));
                _1374 = _666;
                break;
            }
            float2 _675 = _495 + _656;
            int _1314;
            float _1315;
            _1315 = 0.0;
            _1314 = -1;
            float _1369;
            for (; _1314 <= 1; _1315 = _1369, _1314++)
            {
                _1369 = _1315;
                for (int _1367 = -1; _1367 <= 1; )
                {
                    float2 _924 = float2(float(_1367), float(_1314)) * _500;
                    _1369 += abs(_40.sample(_40Smplr, (_495 + _924), level(0.0)).x - _47.sample(_47Smplr, (_675 + _924), level(0.0)).x);
                    _1367++;
                    continue;
                }
            }
            float2 _1317;
            _1317 = _656;
            float _1360;
            float2 _1376;
            int _1316 = -2;
            float _1361 = _1315;
            for (; _1316 <= 2; _1317 = _1376, _1316++, _1361 = _1360)
            {
                _1360 = _1361;
                _1376 = _1317;
                float2 _1377;
                float _1390;
                for (int _1353 = -2; _1353 <= 2; _1360 = _1390, _1353++, _1376 = _1377)
                {
                    if ((_1353 == 0) && (_1316 == 0))
                    {
                        _1390 = _1360;
                        _1377 = _1376;
                        continue;
                    }
                    float2 _700 = float2(float(_1353), float(_1316));
                    float2 _703 = _656 + (_700 * _500);
                    float2 _706 = _495 + _703;
                    int _1355;
                    float _1356;
                    _1356 = 0.0;
                    _1355 = -1;
                    float _1364;
                    for (; _1355 <= 1; _1356 = _1364, _1355++)
                    {
                        _1364 = _1356;
                        for (int _1362 = -1; _1362 <= 1; )
                        {
                            float2 _982 = float2(float(_1362), float(_1355)) * _500;
                            _1364 += abs(_40.sample(_40Smplr, (_495 + _982), level(0.0)).x - _47.sample(_47Smplr, (_706 + _982), level(0.0)).x);
                            _1362++;
                            continue;
                        }
                    }
                    float _716 = _1356 + (0.0500000007450580596923828125 * length(_700));
                    bool _720 = _716 < (_1360 * 0.99989998340606689453125);
                    _1390 = _720 ? _716 : _1360;
                    _1377 = select(_1376, _703, bool2(_720));
                }
            }
            float2 _736 = _495 + _1317;
            int _1319;
            float _1320;
            _1320 = 0.0;
            _1319 = -1;
            float _1352;
            for (; _1319 <= 1; _1320 = _1352, _1319++)
            {
                _1352 = _1320;
                for (int _1350 = -1; _1350 <= 1; )
                {
                    float2 _1040 = float2(float(_1350), float(_1319)) * _500;
                    _1352 += abs(_40.sample(_40Smplr, (_495 + _1040), level(0.0)).x - _47.sample(_47Smplr, (_736 + _1040), level(0.0)).x);
                    _1350++;
                    continue;
                }
            }
            float2 _741 = float2(_500.x, 0.0);
            float2 _744 = float2(0.0, _500.y);
            float2 _749 = _736 - _741;
            int _1322;
            float _1323;
            _1323 = 0.0;
            _1322 = -1;
            float _1349;
            for (; _1322 <= 1; _1323 = _1349, _1322++)
            {
                _1349 = _1323;
                for (int _1347 = -1; _1347 <= 1; )
                {
                    float2 _1098 = float2(float(_1347), float(_1322)) * _500;
                    _1349 += abs(_40.sample(_40Smplr, (_495 + _1098), level(0.0)).x - _47.sample(_47Smplr, (_749 + _1098), level(0.0)).x);
                    _1347++;
                    continue;
                }
            }
            float2 _756 = _736 + _741;
            int _1325;
            float _1326;
            _1326 = 0.0;
            _1325 = -1;
            float _1346;
            for (; _1325 <= 1; _1326 = _1346, _1325++)
            {
                _1346 = _1326;
                for (int _1344 = -1; _1344 <= 1; )
                {
                    float2 _1156 = float2(float(_1344), float(_1325)) * _500;
                    _1346 += abs(_40.sample(_40Smplr, (_495 + _1156), level(0.0)).x - _47.sample(_47Smplr, (_756 + _1156), level(0.0)).x);
                    _1344++;
                    continue;
                }
            }
            float2 _763 = _736 - _744;
            int _1328;
            float _1329;
            _1329 = 0.0;
            _1328 = -1;
            float _1343;
            for (; _1328 <= 1; _1329 = _1343, _1328++)
            {
                _1343 = _1329;
                for (int _1341 = -1; _1341 <= 1; )
                {
                    float2 _1214 = float2(float(_1341), float(_1328)) * _500;
                    _1343 += abs(_40.sample(_40Smplr, (_495 + _1214), level(0.0)).x - _47.sample(_47Smplr, (_763 + _1214), level(0.0)).x);
                    _1341++;
                    continue;
                }
            }
            float2 _770 = _736 + _744;
            int _1331;
            float _1332;
            _1332 = 0.0;
            _1331 = -1;
            float _1340;
            for (; _1331 <= 1; _1332 = _1340, _1331++)
            {
                _1340 = _1332;
                for (int _1338 = -1; _1338 <= 1; )
                {
                    float2 _1272 = float2(float(_1338), float(_1331)) * _500;
                    _1340 += abs(_40.sample(_40Smplr, (_495 + _1272), level(0.0)).x - _47.sample(_47Smplr, (_770 + _1272), level(0.0)).x);
                    _1338++;
                    continue;
                }
            }
            float _778 = fast::max(_1323, _1326) - _1320;
            float _786 = fast::max(_1329, _1332) - _1320;
            float _1333;
            if (_778 > 9.9999999747524270787835121154785e-07)
            {
                _1333 = fast::clamp((0.5 * (_1323 - _1326)) / _778, -0.5, 0.5);
            }
            else
            {
                _1333 = 0.0;
            }
            float _1334;
            if (_786 > 9.9999999747524270787835121154785e-07)
            {
                _1334 = fast::clamp((0.5 * (_1329 - _1332)) / _786, -0.5, 0.5);
            }
            else
            {
                _1334 = 0.0;
            }
            float4 _827 = float4((_1317 + (float2(_1333, _1334) * _500)) / _500, 0.0, 0.0);
            _192.write(_827, uint2(_640));
            _1374 = _827;
            break;
        } while(false);
        _571.write(_1374, uint2(_461));
        break;
    } while(false);
}

