#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template <typename ImageT>
void spvImageFence(ImageT img) { img.fence(); }

struct _334
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float4 _m5[2];
    int _m6;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _334& _336 [[buffer(6)]], texture2d<float> _40 [[texture(1)]], texture2d<float> _47 [[texture(2)]], texture2d<float> _53 [[texture(3)]], texture2d<float, access::read_write> _194 [[texture(4)]], texture2d<float, access::write> _431 [[texture(5)]], sampler _40Smplr [[sampler(1)]], sampler _47Smplr [[sampler(2)]], sampler _53Smplr [[sampler(3)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _329 = int2(gl_GlobalInvocationID.xy);
        bool _341 = _329.x >= int(_336._m0.x);
        bool _352;
        if (!_341)
        {
            _352 = _329.y >= int(_336._m0.y);
        }
        else
        {
            _352 = _341;
        }
        if (_352)
        {
            break;
        }
        float2 _364 = (float2(_329) + float2(0.5)) / _336._m0;
        float2 _370 = float2(1.0) / _336._m1;
        float4 _795;
        do
        {
            int2 _476 = int2(_364 * _336._m2);
            if (_336._m6 == 0)
            {
                spvImageFence(_194);
                _795 = _194.read(uint2(_476));
                break;
            }
            float2 _490 = _53.sample(_53Smplr, ((floor(_364 * _336._m4) + float2(0.5)) / _336._m4), level(0.0)).xy * 2.0;
            float2 _492 = _490 * _370;
            int _766;
            float _767;
            float _768;
            _768 = 1.0;
            _767 = 0.0;
            _766 = -2;
            float _793;
            float _794;
            for (; _766 <= 2; _768 = _793, _767 = _794, _766++)
            {
                _794 = _767;
                _793 = _768;
                for (int _791 = -2; _791 <= 2; )
                {
                    float4 _646 = _47.sample(_47Smplr, (_364 + (float2(float(_791), float(_766)) * _370)), level(0.0));
                    float _624 = _646.x;
                    _794 = fast::max(_794, _624);
                    _793 = fast::min(_793, _624);
                    _791++;
                    continue;
                }
            }
            if ((_767 - _768) < 0.0)
            {
                float4 _502 = float4(_490, 0.0, 0.0);
                _194.write(_502, uint2(_476));
                _795 = _502;
                break;
            }
            float2 _511 = _364 + _492;
            int _769;
            float _770;
            _770 = 0.0;
            _769 = -1;
            float _790;
            for (; _769 <= 1; _770 = _790, _769++)
            {
                _790 = _770;
                for (int _788 = -1; _788 <= 1; )
                {
                    float2 _671 = float2(float(_788), float(_769)) * _370;
                    _790 += abs(_47.sample(_47Smplr, (_364 + _671), level(0.0)).x - _40.sample(_40Smplr, (_511 + _671), level(0.0)).x);
                    _788++;
                    continue;
                }
            }
            float2 _772;
            _772 = _492;
            float _781;
            float2 _797;
            int _771 = -2;
            float _782 = _770;
            for (; _771 <= 2; _772 = _797, _771++, _782 = _781)
            {
                _781 = _782;
                _797 = _772;
                float2 _798;
                float _806;
                for (int _774 = -2; _774 <= 2; _781 = _806, _774++, _797 = _798)
                {
                    if ((_774 == 0) && (_771 == 0))
                    {
                        _806 = _781;
                        _798 = _797;
                        continue;
                    }
                    float2 _536 = float2(float(_774), float(_771));
                    float2 _539 = _492 + (_536 * _370);
                    float2 _542 = _364 + _539;
                    int _776;
                    float _777;
                    _777 = 0.0;
                    _776 = -1;
                    float _785;
                    for (; _776 <= 1; _777 = _785, _776++)
                    {
                        _785 = _777;
                        for (int _783 = -1; _783 <= 1; )
                        {
                            float2 _729 = float2(float(_783), float(_776)) * _370;
                            _785 += abs(_47.sample(_47Smplr, (_364 + _729), level(0.0)).x - _40.sample(_40Smplr, (_542 + _729), level(0.0)).x);
                            _783++;
                            continue;
                        }
                    }
                    float _552 = _777 + (0.0500000007450580596923828125 * length(_536));
                    bool _556 = _552 < (_781 * 0.99989998340606689453125);
                    _806 = _556 ? _552 : _781;
                    _798 = select(_797, _539, bool2(_556));
                }
            }
            float4 _574 = float4(_772 / _370, 0.0, 0.0);
            _194.write(_574, uint2(_476));
            _795 = _574;
            break;
        } while(false);
        _431.write(_795, uint2(_329));
        break;
    } while(false);
}

