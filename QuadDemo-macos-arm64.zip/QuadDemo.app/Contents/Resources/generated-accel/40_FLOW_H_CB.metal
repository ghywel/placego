#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template <typename ImageT>
void spvImageFence(ImageT img) { img.fence(); }

struct _466
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float4 _m5[2];
    int _m6;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _466& _468 [[buffer(6)]], texture2d<float> _40 [[texture(1)]], texture2d<float> _47 [[texture(2)]], texture2d<float> _53 [[texture(3)]], texture2d<float, access::read_write> _192 [[texture(4)]], texture2d<float, access::write> _561 [[texture(5)]], sampler _40Smplr [[sampler(1)]], sampler _47Smplr [[sampler(2)]], sampler _53Smplr [[sampler(3)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _461 = int2(gl_GlobalInvocationID.xy);
        bool _473 = _461.x >= int(_468._m0.x);
        bool _483;
        if (!_473)
        {
            _483 = _461.y >= int(_468._m0.y);
        }
        else
        {
            _483 = _473;
        }
        if (_483)
        {
            break;
        }
        float2 _495 = (float2(_461) + float2(0.5)) / _468._m0;
        float2 _501 = float2(1.0) / _468._m1;
        float4 _1363;
        do
        {
            int2 _629 = int2(_495 * _468._m2);
            if (_468._m6 == 0)
            {
                spvImageFence(_192);
                _1363 = _192.read(uint2(_629));
                break;
            }
            float2 _643 = _53.sample(_53Smplr, ((floor(_495 * _468._m4) + float2(0.5)) / _468._m4), level(0.0)).xy * 2.0;
            float2 _645 = _643 * _501;
            int _1300;
            float _1301;
            float _1302;
            _1302 = 1.0;
            _1301 = 0.0;
            _1300 = -1;
            float _1361;
            float _1362;
            for (; _1300 <= 1; _1302 = _1361, _1301 = _1362, _1300++)
            {
                _1362 = _1301;
                _1361 = _1302;
                for (int _1359 = -1; _1359 <= 1; )
                {
                    float4 _888 = _47.sample(_47Smplr, (_495 + (float2(float(_1359), float(_1300)) * _501)), level(0.0));
                    float _866 = _888.x;
                    _1362 = fast::max(_1362, _866);
                    _1361 = fast::min(_1361, _866);
                    _1359++;
                    continue;
                }
            }
            if ((_1301 - _1302) < 0.0)
            {
                float4 _655 = float4(_643, 0.0, 0.0);
                _192.write(_655, uint2(_629));
                _1363 = _655;
                break;
            }
            float2 _664 = _495 + _645;
            int _1303;
            float _1304;
            _1304 = 0.0;
            _1303 = -1;
            float _1358;
            for (; _1303 <= 1; _1304 = _1358, _1303++)
            {
                _1358 = _1304;
                for (int _1356 = -1; _1356 <= 1; )
                {
                    float2 _913 = float2(float(_1356), float(_1303)) * _501;
                    _1358 += abs(_47.sample(_47Smplr, (_495 + _913), level(0.0)).x - _40.sample(_40Smplr, (_664 + _913), level(0.0)).x);
                    _1356++;
                    continue;
                }
            }
            float2 _1306;
            _1306 = _645;
            float _1349;
            float2 _1365;
            int _1305 = -2;
            float _1350 = _1304;
            for (; _1305 <= 2; _1306 = _1365, _1305++, _1350 = _1349)
            {
                _1349 = _1350;
                _1365 = _1306;
                float2 _1366;
                float _1379;
                for (int _1342 = -2; _1342 <= 2; _1349 = _1379, _1342++, _1365 = _1366)
                {
                    if ((_1342 == 0) && (_1305 == 0))
                    {
                        _1379 = _1349;
                        _1366 = _1365;
                        continue;
                    }
                    float2 _689 = float2(float(_1342), float(_1305));
                    float2 _692 = _645 + (_689 * _501);
                    float2 _695 = _495 + _692;
                    int _1344;
                    float _1345;
                    _1345 = 0.0;
                    _1344 = -1;
                    float _1353;
                    for (; _1344 <= 1; _1345 = _1353, _1344++)
                    {
                        _1353 = _1345;
                        for (int _1351 = -1; _1351 <= 1; )
                        {
                            float2 _971 = float2(float(_1351), float(_1344)) * _501;
                            _1353 += abs(_47.sample(_47Smplr, (_495 + _971), level(0.0)).x - _40.sample(_40Smplr, (_695 + _971), level(0.0)).x);
                            _1351++;
                            continue;
                        }
                    }
                    float _705 = _1345 + (0.0500000007450580596923828125 * length(_689));
                    bool _709 = _705 < (_1349 * 0.99989998340606689453125);
                    _1379 = _709 ? _705 : _1349;
                    _1366 = select(_1365, _692, bool2(_709));
                }
            }
            float2 _725 = _495 + _1306;
            int _1308;
            float _1309;
            _1309 = 0.0;
            _1308 = -1;
            float _1341;
            for (; _1308 <= 1; _1309 = _1341, _1308++)
            {
                _1341 = _1309;
                for (int _1339 = -1; _1339 <= 1; )
                {
                    float2 _1029 = float2(float(_1339), float(_1308)) * _501;
                    _1341 += abs(_47.sample(_47Smplr, (_495 + _1029), level(0.0)).x - _40.sample(_40Smplr, (_725 + _1029), level(0.0)).x);
                    _1339++;
                    continue;
                }
            }
            float2 _730 = float2(_501.x, 0.0);
            float2 _733 = float2(0.0, _501.y);
            float2 _738 = _725 - _730;
            int _1311;
            float _1312;
            _1312 = 0.0;
            _1311 = -1;
            float _1338;
            for (; _1311 <= 1; _1312 = _1338, _1311++)
            {
                _1338 = _1312;
                for (int _1336 = -1; _1336 <= 1; )
                {
                    float2 _1087 = float2(float(_1336), float(_1311)) * _501;
                    _1338 += abs(_47.sample(_47Smplr, (_495 + _1087), level(0.0)).x - _40.sample(_40Smplr, (_738 + _1087), level(0.0)).x);
                    _1336++;
                    continue;
                }
            }
            float2 _745 = _725 + _730;
            int _1314;
            float _1315;
            _1315 = 0.0;
            _1314 = -1;
            float _1335;
            for (; _1314 <= 1; _1315 = _1335, _1314++)
            {
                _1335 = _1315;
                for (int _1333 = -1; _1333 <= 1; )
                {
                    float2 _1145 = float2(float(_1333), float(_1314)) * _501;
                    _1335 += abs(_47.sample(_47Smplr, (_495 + _1145), level(0.0)).x - _40.sample(_40Smplr, (_745 + _1145), level(0.0)).x);
                    _1333++;
                    continue;
                }
            }
            float2 _752 = _725 - _733;
            int _1317;
            float _1318;
            _1318 = 0.0;
            _1317 = -1;
            float _1332;
            for (; _1317 <= 1; _1318 = _1332, _1317++)
            {
                _1332 = _1318;
                for (int _1330 = -1; _1330 <= 1; )
                {
                    float2 _1203 = float2(float(_1330), float(_1317)) * _501;
                    _1332 += abs(_47.sample(_47Smplr, (_495 + _1203), level(0.0)).x - _40.sample(_40Smplr, (_752 + _1203), level(0.0)).x);
                    _1330++;
                    continue;
                }
            }
            float2 _759 = _725 + _733;
            int _1320;
            float _1321;
            _1321 = 0.0;
            _1320 = -1;
            float _1329;
            for (; _1320 <= 1; _1321 = _1329, _1320++)
            {
                _1329 = _1321;
                for (int _1327 = -1; _1327 <= 1; )
                {
                    float2 _1261 = float2(float(_1327), float(_1320)) * _501;
                    _1329 += abs(_47.sample(_47Smplr, (_495 + _1261), level(0.0)).x - _40.sample(_40Smplr, (_759 + _1261), level(0.0)).x);
                    _1327++;
                    continue;
                }
            }
            float _767 = fast::max(_1312, _1315) - _1309;
            float _775 = fast::max(_1318, _1321) - _1309;
            float _1322;
            if (_767 > 9.9999999747524270787835121154785e-07)
            {
                _1322 = fast::clamp((0.5 * (_1312 - _1315)) / _767, -0.5, 0.5);
            }
            else
            {
                _1322 = 0.0;
            }
            float _1323;
            if (_775 > 9.9999999747524270787835121154785e-07)
            {
                _1323 = fast::clamp((0.5 * (_1318 - _1321)) / _775, -0.5, 0.5);
            }
            else
            {
                _1323 = 0.0;
            }
            float4 _816 = float4((_1306 + (float2(_1322, _1323) * _501)) / _501, 0.0, 0.0);
            _192.write(_816, uint2(_629));
            _1363 = _816;
            break;
        } while(false);
        _561.write(_1363, uint2(_461));
        break;
    } while(false);
}

