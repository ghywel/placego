#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template <typename ImageT>
void spvImageFence(ImageT img) { img.fence(); }

struct _334
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float2 _m5;
    float4 _m6[2];
    int _m7;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _334& _336 [[buffer(7)]], texture2d<float> _40 [[texture(2)]], texture2d<float> _47 [[texture(3)]], texture2d<float> _53 [[texture(4)]], texture2d<float, access::read_write> _194 [[texture(5)]], texture2d<float, access::write> _441 [[texture(6)]], sampler _40Smplr [[sampler(2)]], sampler _47Smplr [[sampler(3)]], sampler _53Smplr [[sampler(4)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _329 = int2(gl_GlobalInvocationID.xy);
        bool _341 = _329.x >= int(_336._m0.x);
        bool _352;
        if (!_341)
        {
            _352 = _329.y >= int(_336._m0.y);
        }
        else
        {
            _352 = _341;
        }
        if (_352)
        {
            break;
        }
        float2 _364 = (float2(_329) + float2(0.5)) / _336._m0;
        float2 _370 = float2(1.0) / _336._m1;
        float4 _806;
        do
        {
            int2 _487 = int2(_364 * _336._m2);
            if (_336._m7 == 0)
            {
                spvImageFence(_194);
                _806 = _194.read(uint2(_487));
                break;
            }
            float2 _501 = _53.sample(_53Smplr, ((floor(_364 * _336._m5) + float2(0.5)) / _336._m5), level(0.0)).xy * 2.0;
            float2 _503 = _501 * _370;
            int _777;
            float _778;
            float _779;
            _779 = 1.0;
            _778 = 0.0;
            _777 = -2;
            float _804;
            float _805;
            for (; _777 <= 2; _779 = _804, _778 = _805, _777++)
            {
                _805 = _778;
                _804 = _779;
                for (int _802 = -2; _802 <= 2; )
                {
                    float4 _657 = _47.sample(_47Smplr, (_364 + (float2(float(_802), float(_777)) * _370)), level(0.0));
                    float _635 = _657.x;
                    _805 = fast::max(_805, _635);
                    _804 = fast::min(_804, _635);
                    _802++;
                    continue;
                }
            }
            if ((_778 - _779) < 0.0)
            {
                float4 _513 = float4(_501, 0.0, 0.0);
                _194.write(_513, uint2(_487));
                _806 = _513;
                break;
            }
            float2 _522 = _364 + _503;
            int _780;
            float _781;
            _781 = 0.0;
            _780 = -1;
            float _801;
            for (; _780 <= 1; _781 = _801, _780++)
            {
                _801 = _781;
                for (int _799 = -1; _799 <= 1; )
                {
                    float2 _682 = float2(float(_799), float(_780)) * _370;
                    _801 += abs(_47.sample(_47Smplr, (_364 + _682), level(0.0)).x - _40.sample(_40Smplr, (_522 + _682), level(0.0)).x);
                    _799++;
                    continue;
                }
            }
            float2 _783;
            _783 = _503;
            float _792;
            float2 _808;
            int _782 = -2;
            float _793 = _781;
            for (; _782 <= 2; _783 = _808, _782++, _793 = _792)
            {
                _792 = _793;
                _808 = _783;
                float2 _809;
                float _817;
                for (int _785 = -2; _785 <= 2; _792 = _817, _785++, _808 = _809)
                {
                    if ((_785 == 0) && (_782 == 0))
                    {
                        _817 = _792;
                        _809 = _808;
                        continue;
                    }
                    float2 _547 = float2(float(_785), float(_782));
                    float2 _550 = _503 + (_547 * _370);
                    float2 _553 = _364 + _550;
                    int _787;
                    float _788;
                    _788 = 0.0;
                    _787 = -1;
                    float _796;
                    for (; _787 <= 1; _788 = _796, _787++)
                    {
                        _796 = _788;
                        for (int _794 = -1; _794 <= 1; )
                        {
                            float2 _740 = float2(float(_794), float(_787)) * _370;
                            _796 += abs(_47.sample(_47Smplr, (_364 + _740), level(0.0)).x - _40.sample(_40Smplr, (_553 + _740), level(0.0)).x);
                            _794++;
                            continue;
                        }
                    }
                    float _563 = _788 + (0.0500000007450580596923828125 * length(_547));
                    bool _567 = _563 < (_792 * 0.99989998340606689453125);
                    _817 = _567 ? _563 : _792;
                    _809 = select(_808, _550, bool2(_567));
                }
            }
            float4 _585 = float4(_783 / _370, 0.0, 0.0);
            _194.write(_585, uint2(_487));
            _806 = _585;
            break;
        } while(false);
        _441.write(_806, uint2(_329));
        break;
    } while(false);
}

