#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template <typename ImageT>
void spvImageFence(ImageT img) { img.fence(); }

struct _308
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float4 _m3[2];
    int _m4;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _308& _310 [[buffer(4)]], texture2d<float> _32 [[texture(0)]], texture2d<float> _39 [[texture(1)]], texture2d<float, access::read_write> _169 [[texture(2)]], texture2d<float, access::write> _386 [[texture(3)]], sampler _32Smplr [[sampler(0)]], sampler _39Smplr [[sampler(1)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _303 = int2(gl_GlobalInvocationID.xy);
        bool _315 = _303.x >= int(_310._m0.x);
        bool _326;
        if (!_315)
        {
            _326 = _303.y >= int(_310._m0.y);
        }
        else
        {
            _326 = _315;
        }
        if (_326)
        {
            break;
        }
        float2 _338 = (float2(_303) + float2(0.5)) / _310._m0;
        float2 _343 = float2(1.0) / _310._m1;
        float4 _738;
        do
        {
            int2 _429 = int2(_338 * _310._m1);
            if (_310._m4 == 0)
            {
                spvImageFence(_169);
                _738 = _169.read(uint2(_429));
                break;
            }
            int _700;
            float _701;
            float _702;
            _702 = 1.0;
            _701 = 0.0;
            _700 = -2;
            float _736;
            float _737;
            for (; _700 <= 2; _702 = _736, _701 = _737, _700++)
            {
                _737 = _701;
                _736 = _702;
                for (int _734 = -2; _734 <= 2; )
                {
                    float4 _580 = _32.sample(_32Smplr, (_338 + (float2(float(_734), float(_700)) * _343)), level(0.0));
                    float _558 = _580.x;
                    _737 = fast::max(_737, _558);
                    _736 = fast::min(_736, _558);
                    _734++;
                    continue;
                }
            }
            if ((_701 - _702) < 0.0199999995529651641845703125)
            {
                _169.write(float4(0.0), uint2(_429));
                _738 = float4(0.0);
                break;
            }
            int _703;
            float _704;
            _704 = 0.0;
            _703 = -1;
            float _733;
            for (; _703 <= 1; _704 = _733, _703++)
            {
                _733 = _704;
                for (int _731 = -1; _731 <= 1; )
                {
                    float2 _608 = _338 + (float2(float(_731), float(_703)) * _343);
                    _733 += abs(_32.sample(_32Smplr, _608, level(0.0)).x - _39.sample(_39Smplr, _608, level(0.0)).x);
                    _731++;
                    continue;
                }
            }
            float2 _706;
            _706 = float2(0.0);
            float _513;
            float2 _709;
            float _722;
            int _705 = 0;
            float _711 = 0.75;
            float _723 = _704;
            for (; _705 < 5; _711 = _513, _706 = _709, _705++, _723 = _722)
            {
                _709 = _706;
                _722 = _723;
                float _721;
                float2 _740;
                for (int _708 = -1; _708 <= 1; _709 = _740, _708++, _722 = _721)
                {
                    _721 = _722;
                    _740 = _709;
                    float2 _741;
                    float _762;
                    for (int _713 = -1; _713 <= 1; _721 = _762, _713++, _740 = _741)
                    {
                        if ((_713 == 0) && (_708 == 0))
                        {
                            _762 = _721;
                            _741 = _740;
                            continue;
                        }
                        float2 _483 = _706 + ((float2(float(_713), float(_708)) * _711) * _343);
                        float2 _486 = _338 + _483;
                        int _718;
                        float _719;
                        _719 = 0.0;
                        _718 = -1;
                        float _726;
                        for (; _718 <= 1; _719 = _726, _718++)
                        {
                            _726 = _719;
                            for (int _724 = -1; _724 <= 1; )
                            {
                                float2 _663 = float2(float(_724), float(_718)) * _343;
                                _726 += abs(_32.sample(_32Smplr, (_338 + _663), level(0.0)).x - _39.sample(_39Smplr, (_486 + _663), level(0.0)).x);
                                _724++;
                                continue;
                            }
                        }
                        float _494 = _719 + (0.0599999986588954925537109375 * length(_483 / _343));
                        bool _498 = _494 < (_721 * 0.99989998340606689453125);
                        _762 = _498 ? _494 : _721;
                        _741 = select(_740, _483, bool2(_498));
                    }
                }
                _513 = _711 * 0.5;
            }
            float4 _523 = float4(_706 / _343, 0.0, 0.0);
            _169.write(_523, uint2(_429));
            _738 = _523;
            break;
        } while(false);
        _386.write(_738, uint2(_303));
        break;
    } while(false);
}

