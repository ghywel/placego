#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template <typename ImageT>
void spvImageFence(ImageT img) { img.fence(); }

struct _308
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float4 _m4[2];
    int _m5;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _308& _310 [[buffer(5)]], texture2d<float> _32 [[texture(1)]], texture2d<float> _39 [[texture(2)]], texture2d<float, access::read_write> _169 [[texture(3)]], texture2d<float, access::write> _395 [[texture(4)]], sampler _32Smplr [[sampler(1)]], sampler _39Smplr [[sampler(2)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _303 = int2(gl_GlobalInvocationID.xy);
        bool _315 = _303.x >= int(_310._m0.x);
        bool _326;
        if (!_315)
        {
            _326 = _303.y >= int(_310._m0.y);
        }
        else
        {
            _326 = _315;
        }
        if (_326)
        {
            break;
        }
        float2 _338 = (float2(_303) + float2(0.5)) / _310._m0;
        float2 _343 = float2(1.0) / _310._m1;
        float4 _748;
        do
        {
            int2 _439 = int2(_338 * _310._m1);
            if (_310._m5 == 0)
            {
                spvImageFence(_169);
                _748 = _169.read(uint2(_439));
                break;
            }
            int _710;
            float _711;
            float _712;
            _712 = 1.0;
            _711 = 0.0;
            _710 = -2;
            float _746;
            float _747;
            for (; _710 <= 2; _712 = _746, _711 = _747, _710++)
            {
                _747 = _711;
                _746 = _712;
                for (int _744 = -2; _744 <= 2; )
                {
                    float4 _590 = _32.sample(_32Smplr, (_338 + (float2(float(_744), float(_710)) * _343)), level(0.0));
                    float _568 = _590.x;
                    _747 = fast::max(_747, _568);
                    _746 = fast::min(_746, _568);
                    _744++;
                    continue;
                }
            }
            if ((_711 - _712) < 0.0199999995529651641845703125)
            {
                _169.write(float4(0.0), uint2(_439));
                _748 = float4(0.0);
                break;
            }
            int _713;
            float _714;
            _714 = 0.0;
            _713 = -1;
            float _743;
            for (; _713 <= 1; _714 = _743, _713++)
            {
                _743 = _714;
                for (int _741 = -1; _741 <= 1; )
                {
                    float2 _618 = _338 + (float2(float(_741), float(_713)) * _343);
                    _743 += abs(_32.sample(_32Smplr, _618, level(0.0)).x - _39.sample(_39Smplr, _618, level(0.0)).x);
                    _741++;
                    continue;
                }
            }
            float2 _716;
            _716 = float2(0.0);
            float _523;
            float2 _719;
            float _732;
            int _715 = 0;
            float _721 = 0.75;
            float _733 = _714;
            for (; _715 < 5; _721 = _523, _716 = _719, _715++, _733 = _732)
            {
                _719 = _716;
                _732 = _733;
                float _731;
                float2 _750;
                for (int _718 = -1; _718 <= 1; _719 = _750, _718++, _732 = _731)
                {
                    _731 = _732;
                    _750 = _719;
                    float2 _751;
                    float _772;
                    for (int _723 = -1; _723 <= 1; _731 = _772, _723++, _750 = _751)
                    {
                        if ((_723 == 0) && (_718 == 0))
                        {
                            _772 = _731;
                            _751 = _750;
                            continue;
                        }
                        float2 _493 = _716 + ((float2(float(_723), float(_718)) * _721) * _343);
                        float2 _496 = _338 + _493;
                        int _728;
                        float _729;
                        _729 = 0.0;
                        _728 = -1;
                        float _736;
                        for (; _728 <= 1; _729 = _736, _728++)
                        {
                            _736 = _729;
                            for (int _734 = -1; _734 <= 1; )
                            {
                                float2 _673 = float2(float(_734), float(_728)) * _343;
                                _736 += abs(_32.sample(_32Smplr, (_338 + _673), level(0.0)).x - _39.sample(_39Smplr, (_496 + _673), level(0.0)).x);
                                _734++;
                                continue;
                            }
                        }
                        float _504 = _729 + (0.0599999986588954925537109375 * length(_493 / _343));
                        bool _508 = _504 < (_731 * 0.99989998340606689453125);
                        _772 = _508 ? _504 : _731;
                        _751 = select(_750, _493, bool2(_508));
                    }
                }
                _523 = _721 * 0.5;
            }
            float4 _533 = float4(_716 / _343, 0.0, 0.0);
            _169.write(_533, uint2(_439));
            _748 = _533;
            break;
        } while(false);
        _395.write(_748, uint2(_303));
        break;
    } while(false);
}

