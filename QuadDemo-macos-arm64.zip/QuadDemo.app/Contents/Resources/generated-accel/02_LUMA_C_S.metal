#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct _61
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float4 _m5[2];
    int _m6;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _61& _63 [[buffer(5)]], texture2d<float> _20 [[texture(2)]], texture2d<float, access::write> _168 [[texture(4)]], sampler _20Smplr [[sampler(2)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _53 = int2(gl_GlobalInvocationID.xy);
        bool _69 = _53.x >= int(_63._m0.x);
        bool _80;
        if (!_69)
        {
            _80 = _53.y >= int(_63._m0.y);
        }
        else
        {
            _80 = _69;
        }
        if (_80)
        {
            break;
        }
        _168.write(float4(dot(_20.sample(_20Smplr, ((float2(_53) + float2(0.5)) / _63._m0), level(0.0)).xyz, float3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)), 0.0, 0.0, 0.0), uint2(_53));
        break;
    } while(false);
}

