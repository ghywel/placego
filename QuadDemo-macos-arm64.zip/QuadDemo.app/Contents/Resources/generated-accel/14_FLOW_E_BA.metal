#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template <typename ImageT>
void spvImageFence(ImageT img) { img.fence(); }

struct _334
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float4 _m4[2];
    int _m5;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _334& _336 [[buffer(5)]], texture2d<float> _40 [[texture(0)]], texture2d<float> _47 [[texture(1)]], texture2d<float> _53 [[texture(2)]], texture2d<float, access::read_write> _194 [[texture(3)]], texture2d<float, access::write> _421 [[texture(4)]], sampler _40Smplr [[sampler(0)]], sampler _47Smplr [[sampler(1)]], sampler _53Smplr [[sampler(2)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _329 = int2(gl_GlobalInvocationID.xy);
        bool _341 = _329.x >= int(_336._m0.x);
        bool _352;
        if (!_341)
        {
            _352 = _329.y >= int(_336._m0.y);
        }
        else
        {
            _352 = _341;
        }
        if (_352)
        {
            break;
        }
        float2 _364 = (float2(_329) + float2(0.5)) / _336._m0;
        float2 _370 = float2(1.0) / _336._m1;
        float4 _784;
        do
        {
            int2 _465 = int2(_364 * _336._m2);
            if (_336._m5 == 0)
            {
                spvImageFence(_194);
                _784 = _194.read(uint2(_465));
                break;
            }
            float2 _479 = _53.sample(_53Smplr, ((floor(_364 * _336._m3) + float2(0.5)) / _336._m3), level(0.0)).xy * 2.0;
            float2 _481 = _479 * _370;
            int _755;
            float _756;
            float _757;
            _757 = 1.0;
            _756 = 0.0;
            _755 = -2;
            float _782;
            float _783;
            for (; _755 <= 2; _757 = _782, _756 = _783, _755++)
            {
                _783 = _756;
                _782 = _757;
                for (int _780 = -2; _780 <= 2; )
                {
                    float4 _635 = _47.sample(_47Smplr, (_364 + (float2(float(_780), float(_755)) * _370)), level(0.0));
                    float _613 = _635.x;
                    _783 = fast::max(_783, _613);
                    _782 = fast::min(_782, _613);
                    _780++;
                    continue;
                }
            }
            if ((_756 - _757) < 0.0)
            {
                float4 _491 = float4(_479, 0.0, 0.0);
                _194.write(_491, uint2(_465));
                _784 = _491;
                break;
            }
            float2 _500 = _364 + _481;
            int _758;
            float _759;
            _759 = 0.0;
            _758 = -1;
            float _779;
            for (; _758 <= 1; _759 = _779, _758++)
            {
                _779 = _759;
                for (int _777 = -1; _777 <= 1; )
                {
                    float2 _660 = float2(float(_777), float(_758)) * _370;
                    _779 += abs(_47.sample(_47Smplr, (_364 + _660), level(0.0)).x - _40.sample(_40Smplr, (_500 + _660), level(0.0)).x);
                    _777++;
                    continue;
                }
            }
            float2 _761;
            _761 = _481;
            float _770;
            float2 _786;
            int _760 = -2;
            float _771 = _759;
            for (; _760 <= 2; _761 = _786, _760++, _771 = _770)
            {
                _770 = _771;
                _786 = _761;
                float2 _787;
                float _795;
                for (int _763 = -2; _763 <= 2; _770 = _795, _763++, _786 = _787)
                {
                    if ((_763 == 0) && (_760 == 0))
                    {
                        _795 = _770;
                        _787 = _786;
                        continue;
                    }
                    float2 _525 = float2(float(_763), float(_760));
                    float2 _528 = _481 + (_525 * _370);
                    float2 _531 = _364 + _528;
                    int _765;
                    float _766;
                    _766 = 0.0;
                    _765 = -1;
                    float _774;
                    for (; _765 <= 1; _766 = _774, _765++)
                    {
                        _774 = _766;
                        for (int _772 = -1; _772 <= 1; )
                        {
                            float2 _718 = float2(float(_772), float(_765)) * _370;
                            _774 += abs(_47.sample(_47Smplr, (_364 + _718), level(0.0)).x - _40.sample(_40Smplr, (_531 + _718), level(0.0)).x);
                            _772++;
                            continue;
                        }
                    }
                    float _541 = _766 + (0.0500000007450580596923828125 * length(_525));
                    bool _545 = _541 < (_770 * 0.99989998340606689453125);
                    _795 = _545 ? _541 : _770;
                    _787 = select(_786, _528, bool2(_545));
                }
            }
            float4 _563 = float4(_761 / _370, 0.0, 0.0);
            _194.write(_563, uint2(_465));
            _784 = _563;
            break;
        } while(false);
        _421.write(_784, uint2(_329));
        break;
    } while(false);
}

