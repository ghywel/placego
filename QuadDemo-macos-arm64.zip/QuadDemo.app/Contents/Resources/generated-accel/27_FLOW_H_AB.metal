#pragma clang diagnostic ignored "-Wmissing-prototypes"
#pragma clang diagnostic ignored "-Wmissing-braces"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template<typename T, size_t Num>
struct spvUnsafeArray
{
    T elements[Num ? Num : 1];
    
    thread T& operator [] (size_t pos) thread
    {
        return elements[pos];
    }
    constexpr const thread T& operator [] (size_t pos) const thread
    {
        return elements[pos];
    }
    
    device T& operator [] (size_t pos) device
    {
        return elements[pos];
    }
    constexpr const device T& operator [] (size_t pos) const device
    {
        return elements[pos];
    }
    
    constexpr const constant T& operator [] (size_t pos) const constant
    {
        return elements[pos];
    }
    
    threadgroup T& operator [] (size_t pos) threadgroup
    {
        return elements[pos];
    }
    constexpr const threadgroup T& operator [] (size_t pos) const threadgroup
    {
        return elements[pos];
    }
};

struct _158
{
    float2 _m0;
    float2 _m1;
    float4 _m2[2];
    int _m3;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _158& _160 [[buffer(2)]], texture2d<float> _20 [[texture(0)]], texture2d<float, access::write> _230 [[texture(1)]], sampler _20Smplr [[sampler(0)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _152 = int2(gl_GlobalInvocationID.xy);
        bool _165 = _152.x >= int(_160._m0.x);
        bool _176;
        if (!_165)
        {
            _176 = _152.y >= int(_160._m0.y);
        }
        else
        {
            _176 = _165;
        }
        if (_176)
        {
            break;
        }
        float2 _189 = (float2(_152) + float2(0.5)) / _160._m0;
        float2 _196 = float2(1.0) / _160._m1;
        float4 _368;
        do
        {
            if (_160._m3 == 0)
            {
                _368 = float4(0.0);
                break;
            }
            int _355;
            _355 = -1;
            spvUnsafeArray<float2, 9> _254;
            int _366;
            for (int _367 = 0; _355 <= 1; _355++, _367 = _366)
            {
                _366 = _367;
                for (int _364 = -1; _364 <= 1; )
                {
                    _254[_366] = _20.sample(_20Smplr, (_189 + (float2(float(_364), float(_355)) * _196)), level(0.0)).xy;
                    _366++;
                    _364++;
                    continue;
                }
            }
            int _356;
            float2 _357;
            _357 = _254[4];
            _356 = 0;
            float _378;
            float2 _369;
            for (float _361 = 1000000015047466219876688855040.0; _356 < 9; _361 = _378, _357 = _369, _356++)
            {
                float _359;
                _359 = 0.0;
                for (int _358 = 0; _358 < 9; )
                {
                    _359 += length(_254[_356] - _254[_358]);
                    _358++;
                    continue;
                }
                bool _330 = _359 < (_361 * 0.99989998340606689453125);
                if (_330)
                {
                    _369 = _254[_356];
                }
                else
                {
                    _369 = _357;
                }
                _378 = _330 ? _359 : _361;
            }
            _368 = float4(_357, 0.0, 0.0);
            break;
        } while(false);
        _230.write(_368, uint2(_152));
        break;
    } while(false);
}

