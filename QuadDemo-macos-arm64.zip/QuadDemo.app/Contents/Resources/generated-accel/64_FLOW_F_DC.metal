#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template <typename ImageT>
void spvImageFence(ImageT img) { img.fence(); }

struct _468
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float2 _m5;
    float4 _m6[2];
    int _m7;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _468& _470 [[buffer(7)]], texture2d<float> _40 [[texture(2)]], texture2d<float> _47 [[texture(3)]], texture2d<float> _53 [[texture(4)]], texture2d<float, access::read_write> _196 [[texture(5)]], texture2d<float, access::write> _573 [[texture(6)]], sampler _40Smplr [[sampler(2)]], sampler _47Smplr [[sampler(3)]], sampler _53Smplr [[sampler(4)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _463 = int2(gl_GlobalInvocationID.xy);
        bool _475 = _463.x >= int(_470._m0.x);
        bool _485;
        if (!_475)
        {
            _485 = _463.y >= int(_470._m0.y);
        }
        else
        {
            _485 = _475;
        }
        if (_485)
        {
            break;
        }
        float2 _497 = (float2(_463) + float2(0.5)) / _470._m0;
        float2 _503 = float2(1.0) / _470._m1;
        float4 _1383;
        do
        {
            int2 _642 = int2(_497 * _470._m2);
            if (_470._m7 == 0)
            {
                spvImageFence(_196);
                _1383 = _196.read(uint2(_642));
                break;
            }
            float2 _656 = _53.sample(_53Smplr, ((floor(_497 * _470._m5) + float2(0.5)) / _470._m5), level(0.0)).xy * 2.0;
            float2 _658 = _656 * _503;
            int _1320;
            float _1321;
            float _1322;
            _1322 = 1.0;
            _1321 = 0.0;
            _1320 = -1;
            float _1381;
            float _1382;
            for (; _1320 <= 1; _1322 = _1381, _1321 = _1382, _1320++)
            {
                _1382 = _1321;
                _1381 = _1322;
                for (int _1379 = -1; _1379 <= 1; )
                {
                    float4 _901 = _47.sample(_47Smplr, (_497 + (float2(float(_1379), float(_1320)) * _503)), level(0.0));
                    float _879 = _901.x;
                    _1382 = fast::max(_1382, _879);
                    _1381 = fast::min(_1381, _879);
                    _1379++;
                    continue;
                }
            }
            if ((_1321 - _1322) < 0.0)
            {
                float4 _668 = float4(_656, 0.0, 0.0);
                _196.write(_668, uint2(_642));
                _1383 = _668;
                break;
            }
            float2 _677 = _497 + _658;
            int _1323;
            float _1324;
            _1324 = 0.0;
            _1323 = -2;
            float _1378;
            for (; _1323 <= 2; _1324 = _1378, _1323++)
            {
                _1378 = _1324;
                for (int _1376 = -2; _1376 <= 2; )
                {
                    float2 _926 = float2(float(_1376), float(_1323)) * _503;
                    _1378 += abs(_47.sample(_47Smplr, (_497 + _926), level(0.0)).x - _40.sample(_40Smplr, (_677 + _926), level(0.0)).x);
                    _1376++;
                    continue;
                }
            }
            float _950 = _1324 * 0.36000001430511474609375;
            float2 _1326;
            _1326 = _658;
            float _1369;
            float2 _1385;
            int _1325 = -2;
            float _1370 = _950;
            for (; _1325 <= 2; _1326 = _1385, _1325++, _1370 = _1369)
            {
                _1369 = _1370;
                _1385 = _1326;
                float2 _1386;
                float _1399;
                for (int _1362 = -2; _1362 <= 2; _1369 = _1399, _1362++, _1385 = _1386)
                {
                    if ((_1362 == 0) && (_1325 == 0))
                    {
                        _1399 = _1369;
                        _1386 = _1385;
                        continue;
                    }
                    float2 _702 = float2(float(_1362), float(_1325));
                    float2 _705 = _658 + (_702 * _503);
                    float2 _708 = _497 + _705;
                    int _1364;
                    float _1365;
                    _1365 = 0.0;
                    _1364 = -2;
                    float _1373;
                    for (; _1364 <= 2; _1365 = _1373, _1364++)
                    {
                        _1373 = _1365;
                        for (int _1371 = -2; _1371 <= 2; )
                        {
                            float2 _985 = float2(float(_1371), float(_1364)) * _503;
                            _1373 += abs(_47.sample(_47Smplr, (_497 + _985), level(0.0)).x - _40.sample(_40Smplr, (_708 + _985), level(0.0)).x);
                            _1371++;
                            continue;
                        }
                    }
                    float _718 = (_1365 * 0.36000001430511474609375) + (0.0500000007450580596923828125 * length(_702));
                    bool _722 = _718 < (_1369 * 0.99989998340606689453125);
                    _1399 = _722 ? _718 : _1369;
                    _1386 = select(_1385, _705, bool2(_722));
                }
            }
            float2 _738 = _497 + _1326;
            int _1328;
            float _1329;
            _1329 = 0.0;
            _1328 = -2;
            float _1361;
            for (; _1328 <= 2; _1329 = _1361, _1328++)
            {
                _1361 = _1329;
                for (int _1359 = -2; _1359 <= 2; )
                {
                    float2 _1044 = float2(float(_1359), float(_1328)) * _503;
                    _1361 += abs(_47.sample(_47Smplr, (_497 + _1044), level(0.0)).x - _40.sample(_40Smplr, (_738 + _1044), level(0.0)).x);
                    _1359++;
                    continue;
                }
            }
            float _1068 = _1329 * 0.36000001430511474609375;
            float2 _743 = float2(_503.x, 0.0);
            float2 _746 = float2(0.0, _503.y);
            float2 _751 = _738 - _743;
            int _1331;
            float _1332;
            _1332 = 0.0;
            _1331 = -2;
            float _1358;
            for (; _1331 <= 2; _1332 = _1358, _1331++)
            {
                _1358 = _1332;
                for (int _1356 = -2; _1356 <= 2; )
                {
                    float2 _1103 = float2(float(_1356), float(_1331)) * _503;
                    _1358 += abs(_47.sample(_47Smplr, (_497 + _1103), level(0.0)).x - _40.sample(_40Smplr, (_751 + _1103), level(0.0)).x);
                    _1356++;
                    continue;
                }
            }
            float _1127 = _1332 * 0.36000001430511474609375;
            float2 _758 = _738 + _743;
            int _1334;
            float _1335;
            _1335 = 0.0;
            _1334 = -2;
            float _1355;
            for (; _1334 <= 2; _1335 = _1355, _1334++)
            {
                _1355 = _1335;
                for (int _1353 = -2; _1353 <= 2; )
                {
                    float2 _1162 = float2(float(_1353), float(_1334)) * _503;
                    _1355 += abs(_47.sample(_47Smplr, (_497 + _1162), level(0.0)).x - _40.sample(_40Smplr, (_758 + _1162), level(0.0)).x);
                    _1353++;
                    continue;
                }
            }
            float _1186 = _1335 * 0.36000001430511474609375;
            float2 _765 = _738 - _746;
            int _1337;
            float _1338;
            _1338 = 0.0;
            _1337 = -2;
            float _1352;
            for (; _1337 <= 2; _1338 = _1352, _1337++)
            {
                _1352 = _1338;
                for (int _1350 = -2; _1350 <= 2; )
                {
                    float2 _1221 = float2(float(_1350), float(_1337)) * _503;
                    _1352 += abs(_47.sample(_47Smplr, (_497 + _1221), level(0.0)).x - _40.sample(_40Smplr, (_765 + _1221), level(0.0)).x);
                    _1350++;
                    continue;
                }
            }
            float _1245 = _1338 * 0.36000001430511474609375;
            float2 _772 = _738 + _746;
            int _1340;
            float _1341;
            _1341 = 0.0;
            _1340 = -2;
            float _1349;
            for (; _1340 <= 2; _1341 = _1349, _1340++)
            {
                _1349 = _1341;
                for (int _1347 = -2; _1347 <= 2; )
                {
                    float2 _1280 = float2(float(_1347), float(_1340)) * _503;
                    _1349 += abs(_47.sample(_47Smplr, (_497 + _1280), level(0.0)).x - _40.sample(_40Smplr, (_772 + _1280), level(0.0)).x);
                    _1347++;
                    continue;
                }
            }
            float _1304 = _1341 * 0.36000001430511474609375;
            float _780 = fast::max(_1127, _1186) - _1068;
            float _788 = fast::max(_1245, _1304) - _1068;
            float _1342;
            if (_780 > 9.9999999747524270787835121154785e-07)
            {
                _1342 = fast::clamp((0.5 * (_1127 - _1186)) / _780, -0.5, 0.5);
            }
            else
            {
                _1342 = 0.0;
            }
            float _1343;
            if (_788 > 9.9999999747524270787835121154785e-07)
            {
                _1343 = fast::clamp((0.5 * (_1245 - _1304)) / _788, -0.5, 0.5);
            }
            else
            {
                _1343 = 0.0;
            }
            float4 _829 = float4((_1326 + (float2(_1342, _1343) * _503)) / _503, 0.0, 0.0);
            _196.write(_829, uint2(_642));
            _1383 = _829;
            break;
        } while(false);
        _573.write(_1383, uint2(_463));
        break;
    } while(false);
}

