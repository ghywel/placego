#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template <typename ImageT>
void spvImageFence(ImageT img) { img.fence(); }

struct _466
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float4 _m4[2];
    int _m5;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _466& _468 [[buffer(5)]], texture2d<float> _40 [[texture(0)]], texture2d<float> _47 [[texture(1)]], texture2d<float> _53 [[texture(2)]], texture2d<float, access::read_write> _192 [[texture(3)]], texture2d<float, access::write> _551 [[texture(4)]], sampler _40Smplr [[sampler(0)]], sampler _47Smplr [[sampler(1)]], sampler _53Smplr [[sampler(2)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _461 = int2(gl_GlobalInvocationID.xy);
        bool _473 = _461.x >= int(_468._m0.x);
        bool _483;
        if (!_473)
        {
            _483 = _461.y >= int(_468._m0.y);
        }
        else
        {
            _483 = _473;
        }
        if (_483)
        {
            break;
        }
        float2 _495 = (float2(_461) + float2(0.5)) / _468._m0;
        float2 _500 = float2(1.0) / _468._m1;
        float4 _1352;
        do
        {
            int2 _618 = int2(_495 * _468._m1);
            if (_468._m5 == 0)
            {
                spvImageFence(_192);
                _1352 = _192.read(uint2(_618));
                break;
            }
            float2 _632 = _53.sample(_53Smplr, ((floor(_495 * _468._m3) + float2(0.5)) / _468._m3), level(0.0)).xy * 2.0;
            float2 _634 = _632 * _500;
            int _1289;
            float _1290;
            float _1291;
            _1291 = 1.0;
            _1290 = 0.0;
            _1289 = -1;
            float _1350;
            float _1351;
            for (; _1289 <= 1; _1291 = _1350, _1290 = _1351, _1289++)
            {
                _1351 = _1290;
                _1350 = _1291;
                for (int _1348 = -1; _1348 <= 1; )
                {
                    float4 _877 = _40.sample(_40Smplr, (_495 + (float2(float(_1348), float(_1289)) * _500)), level(0.0));
                    float _855 = _877.x;
                    _1351 = fast::max(_1351, _855);
                    _1350 = fast::min(_1350, _855);
                    _1348++;
                    continue;
                }
            }
            if ((_1290 - _1291) < 0.0)
            {
                float4 _644 = float4(_632, 0.0, 0.0);
                _192.write(_644, uint2(_618));
                _1352 = _644;
                break;
            }
            float2 _653 = _495 + _634;
            int _1292;
            float _1293;
            _1293 = 0.0;
            _1292 = -1;
            float _1347;
            for (; _1292 <= 1; _1293 = _1347, _1292++)
            {
                _1347 = _1293;
                for (int _1345 = -1; _1345 <= 1; )
                {
                    float2 _902 = float2(float(_1345), float(_1292)) * _500;
                    _1347 += abs(_40.sample(_40Smplr, (_495 + _902), level(0.0)).x - _47.sample(_47Smplr, (_653 + _902), level(0.0)).x);
                    _1345++;
                    continue;
                }
            }
            float2 _1295;
            _1295 = _634;
            float _1338;
            float2 _1354;
            int _1294 = -2;
            float _1339 = _1293;
            for (; _1294 <= 2; _1295 = _1354, _1294++, _1339 = _1338)
            {
                _1338 = _1339;
                _1354 = _1295;
                float2 _1355;
                float _1368;
                for (int _1331 = -2; _1331 <= 2; _1338 = _1368, _1331++, _1354 = _1355)
                {
                    if ((_1331 == 0) && (_1294 == 0))
                    {
                        _1368 = _1338;
                        _1355 = _1354;
                        continue;
                    }
                    float2 _678 = float2(float(_1331), float(_1294));
                    float2 _681 = _634 + (_678 * _500);
                    float2 _684 = _495 + _681;
                    int _1333;
                    float _1334;
                    _1334 = 0.0;
                    _1333 = -1;
                    float _1342;
                    for (; _1333 <= 1; _1334 = _1342, _1333++)
                    {
                        _1342 = _1334;
                        for (int _1340 = -1; _1340 <= 1; )
                        {
                            float2 _960 = float2(float(_1340), float(_1333)) * _500;
                            _1342 += abs(_40.sample(_40Smplr, (_495 + _960), level(0.0)).x - _47.sample(_47Smplr, (_684 + _960), level(0.0)).x);
                            _1340++;
                            continue;
                        }
                    }
                    float _694 = _1334 + (0.0500000007450580596923828125 * length(_678));
                    bool _698 = _694 < (_1338 * 0.99989998340606689453125);
                    _1368 = _698 ? _694 : _1338;
                    _1355 = select(_1354, _681, bool2(_698));
                }
            }
            float2 _714 = _495 + _1295;
            int _1297;
            float _1298;
            _1298 = 0.0;
            _1297 = -1;
            float _1330;
            for (; _1297 <= 1; _1298 = _1330, _1297++)
            {
                _1330 = _1298;
                for (int _1328 = -1; _1328 <= 1; )
                {
                    float2 _1018 = float2(float(_1328), float(_1297)) * _500;
                    _1330 += abs(_40.sample(_40Smplr, (_495 + _1018), level(0.0)).x - _47.sample(_47Smplr, (_714 + _1018), level(0.0)).x);
                    _1328++;
                    continue;
                }
            }
            float2 _719 = float2(_500.x, 0.0);
            float2 _722 = float2(0.0, _500.y);
            float2 _727 = _714 - _719;
            int _1300;
            float _1301;
            _1301 = 0.0;
            _1300 = -1;
            float _1327;
            for (; _1300 <= 1; _1301 = _1327, _1300++)
            {
                _1327 = _1301;
                for (int _1325 = -1; _1325 <= 1; )
                {
                    float2 _1076 = float2(float(_1325), float(_1300)) * _500;
                    _1327 += abs(_40.sample(_40Smplr, (_495 + _1076), level(0.0)).x - _47.sample(_47Smplr, (_727 + _1076), level(0.0)).x);
                    _1325++;
                    continue;
                }
            }
            float2 _734 = _714 + _719;
            int _1303;
            float _1304;
            _1304 = 0.0;
            _1303 = -1;
            float _1324;
            for (; _1303 <= 1; _1304 = _1324, _1303++)
            {
                _1324 = _1304;
                for (int _1322 = -1; _1322 <= 1; )
                {
                    float2 _1134 = float2(float(_1322), float(_1303)) * _500;
                    _1324 += abs(_40.sample(_40Smplr, (_495 + _1134), level(0.0)).x - _47.sample(_47Smplr, (_734 + _1134), level(0.0)).x);
                    _1322++;
                    continue;
                }
            }
            float2 _741 = _714 - _722;
            int _1306;
            float _1307;
            _1307 = 0.0;
            _1306 = -1;
            float _1321;
            for (; _1306 <= 1; _1307 = _1321, _1306++)
            {
                _1321 = _1307;
                for (int _1319 = -1; _1319 <= 1; )
                {
                    float2 _1192 = float2(float(_1319), float(_1306)) * _500;
                    _1321 += abs(_40.sample(_40Smplr, (_495 + _1192), level(0.0)).x - _47.sample(_47Smplr, (_741 + _1192), level(0.0)).x);
                    _1319++;
                    continue;
                }
            }
            float2 _748 = _714 + _722;
            int _1309;
            float _1310;
            _1310 = 0.0;
            _1309 = -1;
            float _1318;
            for (; _1309 <= 1; _1310 = _1318, _1309++)
            {
                _1318 = _1310;
                for (int _1316 = -1; _1316 <= 1; )
                {
                    float2 _1250 = float2(float(_1316), float(_1309)) * _500;
                    _1318 += abs(_40.sample(_40Smplr, (_495 + _1250), level(0.0)).x - _47.sample(_47Smplr, (_748 + _1250), level(0.0)).x);
                    _1316++;
                    continue;
                }
            }
            float _756 = fast::max(_1301, _1304) - _1298;
            float _764 = fast::max(_1307, _1310) - _1298;
            float _1311;
            if (_756 > 9.9999999747524270787835121154785e-07)
            {
                _1311 = fast::clamp((0.5 * (_1301 - _1304)) / _756, -0.5, 0.5);
            }
            else
            {
                _1311 = 0.0;
            }
            float _1312;
            if (_764 > 9.9999999747524270787835121154785e-07)
            {
                _1312 = fast::clamp((0.5 * (_1307 - _1310)) / _764, -0.5, 0.5);
            }
            else
            {
                _1312 = 0.0;
            }
            float4 _805 = float4((_1295 + (float2(_1311, _1312) * _500)) / _500, 0.0, 0.0);
            _192.write(_805, uint2(_618));
            _1352 = _805;
            break;
        } while(false);
        _551.write(_1352, uint2(_461));
        break;
    } while(false);
}

