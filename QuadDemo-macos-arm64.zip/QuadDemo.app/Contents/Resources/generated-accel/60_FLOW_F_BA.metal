#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template <typename ImageT>
void spvImageFence(ImageT img) { img.fence(); }

struct _468
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float4 _m4[2];
    int _m5;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _468& _470 [[buffer(5)]], texture2d<float> _40 [[texture(0)]], texture2d<float> _47 [[texture(1)]], texture2d<float> _53 [[texture(2)]], texture2d<float, access::read_write> _196 [[texture(3)]], texture2d<float, access::write> _553 [[texture(4)]], sampler _40Smplr [[sampler(0)]], sampler _47Smplr [[sampler(1)]], sampler _53Smplr [[sampler(2)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _463 = int2(gl_GlobalInvocationID.xy);
        bool _475 = _463.x >= int(_470._m0.x);
        bool _485;
        if (!_475)
        {
            _485 = _463.y >= int(_470._m0.y);
        }
        else
        {
            _485 = _475;
        }
        if (_485)
        {
            break;
        }
        float2 _497 = (float2(_463) + float2(0.5)) / _470._m0;
        float2 _503 = float2(1.0) / _470._m1;
        float4 _1361;
        do
        {
            int2 _620 = int2(_497 * _470._m2);
            if (_470._m5 == 0)
            {
                spvImageFence(_196);
                _1361 = _196.read(uint2(_620));
                break;
            }
            float2 _634 = _53.sample(_53Smplr, ((floor(_497 * _470._m3) + float2(0.5)) / _470._m3), level(0.0)).xy * 2.0;
            float2 _636 = _634 * _503;
            int _1298;
            float _1299;
            float _1300;
            _1300 = 1.0;
            _1299 = 0.0;
            _1298 = -1;
            float _1359;
            float _1360;
            for (; _1298 <= 1; _1300 = _1359, _1299 = _1360, _1298++)
            {
                _1360 = _1299;
                _1359 = _1300;
                for (int _1357 = -1; _1357 <= 1; )
                {
                    float4 _879 = _47.sample(_47Smplr, (_497 + (float2(float(_1357), float(_1298)) * _503)), level(0.0));
                    float _857 = _879.x;
                    _1360 = fast::max(_1360, _857);
                    _1359 = fast::min(_1359, _857);
                    _1357++;
                    continue;
                }
            }
            if ((_1299 - _1300) < 0.0)
            {
                float4 _646 = float4(_634, 0.0, 0.0);
                _196.write(_646, uint2(_620));
                _1361 = _646;
                break;
            }
            float2 _655 = _497 + _636;
            int _1301;
            float _1302;
            _1302 = 0.0;
            _1301 = -2;
            float _1356;
            for (; _1301 <= 2; _1302 = _1356, _1301++)
            {
                _1356 = _1302;
                for (int _1354 = -2; _1354 <= 2; )
                {
                    float2 _904 = float2(float(_1354), float(_1301)) * _503;
                    _1356 += abs(_47.sample(_47Smplr, (_497 + _904), level(0.0)).x - _40.sample(_40Smplr, (_655 + _904), level(0.0)).x);
                    _1354++;
                    continue;
                }
            }
            float _928 = _1302 * 0.36000001430511474609375;
            float2 _1304;
            _1304 = _636;
            float _1347;
            float2 _1363;
            int _1303 = -2;
            float _1348 = _928;
            for (; _1303 <= 2; _1304 = _1363, _1303++, _1348 = _1347)
            {
                _1347 = _1348;
                _1363 = _1304;
                float2 _1364;
                float _1377;
                for (int _1340 = -2; _1340 <= 2; _1347 = _1377, _1340++, _1363 = _1364)
                {
                    if ((_1340 == 0) && (_1303 == 0))
                    {
                        _1377 = _1347;
                        _1364 = _1363;
                        continue;
                    }
                    float2 _680 = float2(float(_1340), float(_1303));
                    float2 _683 = _636 + (_680 * _503);
                    float2 _686 = _497 + _683;
                    int _1342;
                    float _1343;
                    _1343 = 0.0;
                    _1342 = -2;
                    float _1351;
                    for (; _1342 <= 2; _1343 = _1351, _1342++)
                    {
                        _1351 = _1343;
                        for (int _1349 = -2; _1349 <= 2; )
                        {
                            float2 _963 = float2(float(_1349), float(_1342)) * _503;
                            _1351 += abs(_47.sample(_47Smplr, (_497 + _963), level(0.0)).x - _40.sample(_40Smplr, (_686 + _963), level(0.0)).x);
                            _1349++;
                            continue;
                        }
                    }
                    float _696 = (_1343 * 0.36000001430511474609375) + (0.0500000007450580596923828125 * length(_680));
                    bool _700 = _696 < (_1347 * 0.99989998340606689453125);
                    _1377 = _700 ? _696 : _1347;
                    _1364 = select(_1363, _683, bool2(_700));
                }
            }
            float2 _716 = _497 + _1304;
            int _1306;
            float _1307;
            _1307 = 0.0;
            _1306 = -2;
            float _1339;
            for (; _1306 <= 2; _1307 = _1339, _1306++)
            {
                _1339 = _1307;
                for (int _1337 = -2; _1337 <= 2; )
                {
                    float2 _1022 = float2(float(_1337), float(_1306)) * _503;
                    _1339 += abs(_47.sample(_47Smplr, (_497 + _1022), level(0.0)).x - _40.sample(_40Smplr, (_716 + _1022), level(0.0)).x);
                    _1337++;
                    continue;
                }
            }
            float _1046 = _1307 * 0.36000001430511474609375;
            float2 _721 = float2(_503.x, 0.0);
            float2 _724 = float2(0.0, _503.y);
            float2 _729 = _716 - _721;
            int _1309;
            float _1310;
            _1310 = 0.0;
            _1309 = -2;
            float _1336;
            for (; _1309 <= 2; _1310 = _1336, _1309++)
            {
                _1336 = _1310;
                for (int _1334 = -2; _1334 <= 2; )
                {
                    float2 _1081 = float2(float(_1334), float(_1309)) * _503;
                    _1336 += abs(_47.sample(_47Smplr, (_497 + _1081), level(0.0)).x - _40.sample(_40Smplr, (_729 + _1081), level(0.0)).x);
                    _1334++;
                    continue;
                }
            }
            float _1105 = _1310 * 0.36000001430511474609375;
            float2 _736 = _716 + _721;
            int _1312;
            float _1313;
            _1313 = 0.0;
            _1312 = -2;
            float _1333;
            for (; _1312 <= 2; _1313 = _1333, _1312++)
            {
                _1333 = _1313;
                for (int _1331 = -2; _1331 <= 2; )
                {
                    float2 _1140 = float2(float(_1331), float(_1312)) * _503;
                    _1333 += abs(_47.sample(_47Smplr, (_497 + _1140), level(0.0)).x - _40.sample(_40Smplr, (_736 + _1140), level(0.0)).x);
                    _1331++;
                    continue;
                }
            }
            float _1164 = _1313 * 0.36000001430511474609375;
            float2 _743 = _716 - _724;
            int _1315;
            float _1316;
            _1316 = 0.0;
            _1315 = -2;
            float _1330;
            for (; _1315 <= 2; _1316 = _1330, _1315++)
            {
                _1330 = _1316;
                for (int _1328 = -2; _1328 <= 2; )
                {
                    float2 _1199 = float2(float(_1328), float(_1315)) * _503;
                    _1330 += abs(_47.sample(_47Smplr, (_497 + _1199), level(0.0)).x - _40.sample(_40Smplr, (_743 + _1199), level(0.0)).x);
                    _1328++;
                    continue;
                }
            }
            float _1223 = _1316 * 0.36000001430511474609375;
            float2 _750 = _716 + _724;
            int _1318;
            float _1319;
            _1319 = 0.0;
            _1318 = -2;
            float _1327;
            for (; _1318 <= 2; _1319 = _1327, _1318++)
            {
                _1327 = _1319;
                for (int _1325 = -2; _1325 <= 2; )
                {
                    float2 _1258 = float2(float(_1325), float(_1318)) * _503;
                    _1327 += abs(_47.sample(_47Smplr, (_497 + _1258), level(0.0)).x - _40.sample(_40Smplr, (_750 + _1258), level(0.0)).x);
                    _1325++;
                    continue;
                }
            }
            float _1282 = _1319 * 0.36000001430511474609375;
            float _758 = fast::max(_1105, _1164) - _1046;
            float _766 = fast::max(_1223, _1282) - _1046;
            float _1320;
            if (_758 > 9.9999999747524270787835121154785e-07)
            {
                _1320 = fast::clamp((0.5 * (_1105 - _1164)) / _758, -0.5, 0.5);
            }
            else
            {
                _1320 = 0.0;
            }
            float _1321;
            if (_766 > 9.9999999747524270787835121154785e-07)
            {
                _1321 = fast::clamp((0.5 * (_1223 - _1282)) / _766, -0.5, 0.5);
            }
            else
            {
                _1321 = 0.0;
            }
            float4 _807 = float4((_1304 + (float2(_1320, _1321) * _503)) / _503, 0.0, 0.0);
            _196.write(_807, uint2(_620));
            _1361 = _807;
            break;
        } while(false);
        _553.write(_1361, uint2(_463));
        break;
    } while(false);
}

