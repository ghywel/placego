#pragma clang diagnostic ignored "-Wmissing-prototypes"
#pragma clang diagnostic ignored "-Wmissing-braces"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template<typename T, size_t Num>
struct spvUnsafeArray
{
    T elements[Num ? Num : 1];
    
    thread T& operator [] (size_t pos) thread
    {
        return elements[pos];
    }
    constexpr const thread T& operator [] (size_t pos) const thread
    {
        return elements[pos];
    }
    
    device T& operator [] (size_t pos) device
    {
        return elements[pos];
    }
    constexpr const device T& operator [] (size_t pos) const device
    {
        return elements[pos];
    }
    
    constexpr const constant T& operator [] (size_t pos) const constant
    {
        return elements[pos];
    }
    
    threadgroup T& operator [] (size_t pos) threadgroup
    {
        return elements[pos];
    }
    constexpr const threadgroup T& operator [] (size_t pos) const threadgroup
    {
        return elements[pos];
    }
};

// Implementation of signed integer mod accurate to SPIR-V specification
template<typename Tx, typename Ty>
inline Tx spvSMod(Tx x, Ty y)
{
    Tx remainder = x - y * (x / y);
    return select(Tx(remainder + y), remainder, remainder == 0 || (x >= 0) == (y >= 0));
}

// Returns the determinant of a 2x2 matrix.
static inline __attribute__((always_inline))
float spvDet2x2(float a1, float a2, float b1, float b2)
{
    return a1 * b2 - b1 * a2;
}

// Returns the inverse of a matrix, by using the algorithm of calculating the classical
// adjoint and dividing by the determinant. The contents of the matrix are changed.
static inline __attribute__((always_inline))
float3x3 spvInverse3x3(float3x3 m)
{
    float3x3 adj;	// The adjoint matrix (inverse after dividing by determinant)

    // Create the transpose of the cofactors, as the classical adjoint of the matrix.
    adj[0][0] =  spvDet2x2(m[1][1], m[1][2], m[2][1], m[2][2]);
    adj[0][1] = -spvDet2x2(m[0][1], m[0][2], m[2][1], m[2][2]);
    adj[0][2] =  spvDet2x2(m[0][1], m[0][2], m[1][1], m[1][2]);

    adj[1][0] = -spvDet2x2(m[1][0], m[1][2], m[2][0], m[2][2]);
    adj[1][1] =  spvDet2x2(m[0][0], m[0][2], m[2][0], m[2][2]);
    adj[1][2] = -spvDet2x2(m[0][0], m[0][2], m[1][0], m[1][2]);

    adj[2][0] =  spvDet2x2(m[1][0], m[1][1], m[2][0], m[2][1]);
    adj[2][1] = -spvDet2x2(m[0][0], m[0][1], m[2][0], m[2][1]);
    adj[2][2] =  spvDet2x2(m[0][0], m[0][1], m[1][0], m[1][1]);

    // Calculate the determinant as a combination of the cofactors of the first row.
    float det = (adj[0][0] * m[0][0]) + (adj[0][1] * m[1][0]) + (adj[0][2] * m[2][0]);

    // Divide the classical adjoint matrix by the determinant.
    // If determinant is zero, matrix is not invertable, so leave it unchanged.
    return (det != 0.0f) ? (adj * (1.0f / det)) : m;
}

struct _1149
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float2 _m5;
    float2 _m6;
    float2 _m7;
    float2 _m8;
    float2 _m9;
    float2 _m10;
    float2 _m11;
    float2 _m12;
    float2 _m13;
    float2 _m14;
    float2 _m15;
    float2 _m16;
    float4 _m17[2];
    int _m18;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _1149& _1151 [[buffer(17)]], texture2d<float> _74 [[texture(0)]], texture2d<float> _81 [[texture(1)]], texture2d<float> _87 [[texture(2)]], texture2d<float> _93 [[texture(3)]], texture2d<float> _99 [[texture(4)]], texture2d<float> _105 [[texture(5)]], texture2d<float> _111 [[texture(6)]], texture2d<float> _135 [[texture(10)]], texture2d<float> _141 [[texture(11)]], texture2d<float> _147 [[texture(12)]], texture2d<float> _153 [[texture(13)]], texture2d<float> _159 [[texture(14)]], texture2d<float, access::write> _1362 [[texture(16)]], sampler _74Smplr [[sampler(0)]], sampler _81Smplr [[sampler(1)]], sampler _87Smplr [[sampler(2)]], sampler _93Smplr [[sampler(3)]], sampler _99Smplr [[sampler(4)]], sampler _105Smplr [[sampler(5)]], sampler _111Smplr [[sampler(6)]], sampler _135Smplr [[sampler(10)]], sampler _141Smplr [[sampler(11)]], sampler _147Smplr [[sampler(12)]], sampler _153Smplr [[sampler(13)]], sampler _159Smplr [[sampler(14)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _1145 = int2(gl_GlobalInvocationID.xy);
        bool _1156 = _1145.x >= int(_1151._m0.x);
        bool _1166;
        if (!_1156)
        {
            _1166 = _1145.y >= int(_1151._m0.y);
        }
        else
        {
            _1166 = _1156;
        }
        if (_1166)
        {
            break;
        }
        float2 _1178 = (float2(_1145) + float2(0.5)) / _1151._m0;
        float2 _1184 = float2(1.0) / _1151._m1;
        spvUnsafeArray<float, 8> _235;
        for (int _2177 = 0; _2177 < 8; )
        {
            _235[_2177] = _1151._m17[_2177 / 4][spvSMod(_2177, 4)];
            _2177++;
            continue;
        }
        float4 _2201;
        do
        {
            int _2208 = (_235[2] <= 0.0) ? 2 : int(_235[1] <= 0.0);
            int _1495 = _2208 + 1;
            float _1500 = _235[_1495] - _235[_2208];
            float4 _1985 = _99.sample(_99Smplr, float2(0.5), level(0.0));
            float _1531 = _1985.x;
            float4 _1990 = _105.sample(_105Smplr, float2(0.5), level(0.0));
            float _1533 = _1990.x;
            bool _1537 = _2208 == 0;
            float _2180;
            if (_1537)
            {
                _2180 = _1531;
            }
            else
            {
                _2180 = (_2208 == 1) ? _1533 : _111.sample(_111Smplr, float2(0.5), level(0.0)).x;
            }
            if (_2180 > 0.125)
            {
                float4 _2200;
                if (fast::clamp((-_235[_2208]) / _1500, 0.0, 1.0) < 0.5)
                {
                    float4 _2199;
                    do
                    {
                        if (_1537)
                        {
                            _2199 = _74.sample(_74Smplr, _1178, level(0.0));
                            break;
                        }
                        if (_2208 == 1)
                        {
                            _2199 = _81.sample(_81Smplr, _1178, level(0.0));
                            break;
                        }
                        if (_2208 == 2)
                        {
                            _2199 = _87.sample(_87Smplr, _1178, level(0.0));
                            break;
                        }
                        _2199 = _93.sample(_93Smplr, _1178, level(0.0));
                        break;
                    } while(false);
                    _2200 = _2199;
                }
                else
                {
                    float4 _2198;
                    do
                    {
                        if (_1495 == 0)
                        {
                            _2198 = _74.sample(_74Smplr, _1178, level(0.0));
                            break;
                        }
                        if (_1495 == 1)
                        {
                            _2198 = _81.sample(_81Smplr, _1178, level(0.0));
                            break;
                        }
                        if (_1495 == 2)
                        {
                            _2198 = _87.sample(_87Smplr, _1178, level(0.0));
                            break;
                        }
                        _2198 = _93.sample(_93Smplr, _1178, level(0.0));
                        break;
                    } while(false);
                    _2200 = _2198;
                }
                _2201 = _2200;
                break;
            }
            float2 _1677 = _141.sample(_141Smplr, _1178, level(0.0)).xy * _1184;
            float2 _1682 = _147.sample(_147Smplr, _1178, level(0.0)).xy * _1184;
            float2 _1685 = _1178 + _1682;
            float2 _1692 = _1682 + (_159.sample(_159Smplr, _1685, level(0.0)).xy * _1184);
            float _1705 = length(_1184);
            float _1743 = (_235[0] - _235[1]) / _1500;
            float _1750 = (_235[2] - _235[1]) / _1500;
            float _1757 = (_235[3] - _235[1]) / _1500;
            float _1770 = _1743 * _1743;
            float _1773 = _1750 * _1750;
            float _1776 = _1757 * _1757;
            float3x3 _1809 = float3x3(float3(_1743, _1750, _1757), float3(_1770, _1773, _1776) * 0.5, float3(_1770 * _1743, _1773 * _1750, _1776 * _1757) * float3(0.16666667163372039794921875));
            float2 _2193;
            if (abs(determinant(_1809)) > 9.9999997473787516355514526367188e-05)
            {
                float3x3 _1816 = spvInverse3x3(_1809);
                _2193 = float2((_1816 * float3(_1677.x, _1682.x, _1692.x)).y, (_1816 * float3(_1677.y, _1682.y, _1692.y)).y);
            }
            else
            {
                _2193 = float2(0.0);
            }
            float2 _1877 = _1184 * 16.0;
            bool _1940 = _1178.x < (24.0 * _1184.x);
            bool _1949;
            if (_1940)
            {
                _1949 = _1178.y < (24.0 * _1184.y);
            }
            else
            {
                _1949 = _1940;
            }
            if (_1949)
            {
                _2201 = float4(0.20000000298023223876953125, 0.60000002384185791015625, 1.0, 1.0);
                break;
            }
            _2201 = float4(float2(0.5) + ((fast::clamp(select(_2193 * (1.0 - smoothstep(2.0, 5.0, fast::max(length(_1677 + (_135.sample(_135Smplr, (_1178 + _1677), level(0.0)).xy * _1184)) / _1705, length(_1682 + (_153.sample(_153Smplr, _1685, level(0.0)).xy * _1184)) / _1705))), float2(0.0), bool2(fast::max(_1531, _1533) > 0.125)), -_1877, _1877) / _1184) * 0.125), 0.5, 1.0);
            break;
        } while(false);
        _1362.write(_2201, uint2(_1145));
        break;
    } while(false);
}

