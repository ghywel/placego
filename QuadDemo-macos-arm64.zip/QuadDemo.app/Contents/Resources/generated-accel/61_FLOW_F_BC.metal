#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template <typename ImageT>
void spvImageFence(ImageT img) { img.fence(); }

struct _468
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float4 _m5[2];
    int _m6;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _468& _470 [[buffer(6)]], texture2d<float> _40 [[texture(1)]], texture2d<float> _47 [[texture(2)]], texture2d<float> _53 [[texture(3)]], texture2d<float, access::read_write> _196 [[texture(4)]], texture2d<float, access::write> _563 [[texture(5)]], sampler _40Smplr [[sampler(1)]], sampler _47Smplr [[sampler(2)]], sampler _53Smplr [[sampler(3)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _463 = int2(gl_GlobalInvocationID.xy);
        bool _475 = _463.x >= int(_470._m0.x);
        bool _485;
        if (!_475)
        {
            _485 = _463.y >= int(_470._m0.y);
        }
        else
        {
            _485 = _475;
        }
        if (_485)
        {
            break;
        }
        float2 _497 = (float2(_463) + float2(0.5)) / _470._m0;
        float2 _502 = float2(1.0) / _470._m1;
        float4 _1372;
        do
        {
            int2 _631 = int2(_497 * _470._m1);
            if (_470._m6 == 0)
            {
                spvImageFence(_196);
                _1372 = _196.read(uint2(_631));
                break;
            }
            float2 _645 = _53.sample(_53Smplr, ((floor(_497 * _470._m4) + float2(0.5)) / _470._m4), level(0.0)).xy * 2.0;
            float2 _647 = _645 * _502;
            int _1309;
            float _1310;
            float _1311;
            _1311 = 1.0;
            _1310 = 0.0;
            _1309 = -1;
            float _1370;
            float _1371;
            for (; _1309 <= 1; _1311 = _1370, _1310 = _1371, _1309++)
            {
                _1371 = _1310;
                _1370 = _1311;
                for (int _1368 = -1; _1368 <= 1; )
                {
                    float4 _890 = _40.sample(_40Smplr, (_497 + (float2(float(_1368), float(_1309)) * _502)), level(0.0));
                    float _868 = _890.x;
                    _1371 = fast::max(_1371, _868);
                    _1370 = fast::min(_1370, _868);
                    _1368++;
                    continue;
                }
            }
            if ((_1310 - _1311) < 0.0)
            {
                float4 _657 = float4(_645, 0.0, 0.0);
                _196.write(_657, uint2(_631));
                _1372 = _657;
                break;
            }
            float2 _666 = _497 + _647;
            int _1312;
            float _1313;
            _1313 = 0.0;
            _1312 = -2;
            float _1367;
            for (; _1312 <= 2; _1313 = _1367, _1312++)
            {
                _1367 = _1313;
                for (int _1365 = -2; _1365 <= 2; )
                {
                    float2 _915 = float2(float(_1365), float(_1312)) * _502;
                    _1367 += abs(_40.sample(_40Smplr, (_497 + _915), level(0.0)).x - _47.sample(_47Smplr, (_666 + _915), level(0.0)).x);
                    _1365++;
                    continue;
                }
            }
            float _939 = _1313 * 0.36000001430511474609375;
            float2 _1315;
            _1315 = _647;
            float _1358;
            float2 _1374;
            int _1314 = -2;
            float _1359 = _939;
            for (; _1314 <= 2; _1315 = _1374, _1314++, _1359 = _1358)
            {
                _1358 = _1359;
                _1374 = _1315;
                float2 _1375;
                float _1388;
                for (int _1351 = -2; _1351 <= 2; _1358 = _1388, _1351++, _1374 = _1375)
                {
                    if ((_1351 == 0) && (_1314 == 0))
                    {
                        _1388 = _1358;
                        _1375 = _1374;
                        continue;
                    }
                    float2 _691 = float2(float(_1351), float(_1314));
                    float2 _694 = _647 + (_691 * _502);
                    float2 _697 = _497 + _694;
                    int _1353;
                    float _1354;
                    _1354 = 0.0;
                    _1353 = -2;
                    float _1362;
                    for (; _1353 <= 2; _1354 = _1362, _1353++)
                    {
                        _1362 = _1354;
                        for (int _1360 = -2; _1360 <= 2; )
                        {
                            float2 _974 = float2(float(_1360), float(_1353)) * _502;
                            _1362 += abs(_40.sample(_40Smplr, (_497 + _974), level(0.0)).x - _47.sample(_47Smplr, (_697 + _974), level(0.0)).x);
                            _1360++;
                            continue;
                        }
                    }
                    float _707 = (_1354 * 0.36000001430511474609375) + (0.0500000007450580596923828125 * length(_691));
                    bool _711 = _707 < (_1358 * 0.99989998340606689453125);
                    _1388 = _711 ? _707 : _1358;
                    _1375 = select(_1374, _694, bool2(_711));
                }
            }
            float2 _727 = _497 + _1315;
            int _1317;
            float _1318;
            _1318 = 0.0;
            _1317 = -2;
            float _1350;
            for (; _1317 <= 2; _1318 = _1350, _1317++)
            {
                _1350 = _1318;
                for (int _1348 = -2; _1348 <= 2; )
                {
                    float2 _1033 = float2(float(_1348), float(_1317)) * _502;
                    _1350 += abs(_40.sample(_40Smplr, (_497 + _1033), level(0.0)).x - _47.sample(_47Smplr, (_727 + _1033), level(0.0)).x);
                    _1348++;
                    continue;
                }
            }
            float _1057 = _1318 * 0.36000001430511474609375;
            float2 _732 = float2(_502.x, 0.0);
            float2 _735 = float2(0.0, _502.y);
            float2 _740 = _727 - _732;
            int _1320;
            float _1321;
            _1321 = 0.0;
            _1320 = -2;
            float _1347;
            for (; _1320 <= 2; _1321 = _1347, _1320++)
            {
                _1347 = _1321;
                for (int _1345 = -2; _1345 <= 2; )
                {
                    float2 _1092 = float2(float(_1345), float(_1320)) * _502;
                    _1347 += abs(_40.sample(_40Smplr, (_497 + _1092), level(0.0)).x - _47.sample(_47Smplr, (_740 + _1092), level(0.0)).x);
                    _1345++;
                    continue;
                }
            }
            float _1116 = _1321 * 0.36000001430511474609375;
            float2 _747 = _727 + _732;
            int _1323;
            float _1324;
            _1324 = 0.0;
            _1323 = -2;
            float _1344;
            for (; _1323 <= 2; _1324 = _1344, _1323++)
            {
                _1344 = _1324;
                for (int _1342 = -2; _1342 <= 2; )
                {
                    float2 _1151 = float2(float(_1342), float(_1323)) * _502;
                    _1344 += abs(_40.sample(_40Smplr, (_497 + _1151), level(0.0)).x - _47.sample(_47Smplr, (_747 + _1151), level(0.0)).x);
                    _1342++;
                    continue;
                }
            }
            float _1175 = _1324 * 0.36000001430511474609375;
            float2 _754 = _727 - _735;
            int _1326;
            float _1327;
            _1327 = 0.0;
            _1326 = -2;
            float _1341;
            for (; _1326 <= 2; _1327 = _1341, _1326++)
            {
                _1341 = _1327;
                for (int _1339 = -2; _1339 <= 2; )
                {
                    float2 _1210 = float2(float(_1339), float(_1326)) * _502;
                    _1341 += abs(_40.sample(_40Smplr, (_497 + _1210), level(0.0)).x - _47.sample(_47Smplr, (_754 + _1210), level(0.0)).x);
                    _1339++;
                    continue;
                }
            }
            float _1234 = _1327 * 0.36000001430511474609375;
            float2 _761 = _727 + _735;
            int _1329;
            float _1330;
            _1330 = 0.0;
            _1329 = -2;
            float _1338;
            for (; _1329 <= 2; _1330 = _1338, _1329++)
            {
                _1338 = _1330;
                for (int _1336 = -2; _1336 <= 2; )
                {
                    float2 _1269 = float2(float(_1336), float(_1329)) * _502;
                    _1338 += abs(_40.sample(_40Smplr, (_497 + _1269), level(0.0)).x - _47.sample(_47Smplr, (_761 + _1269), level(0.0)).x);
                    _1336++;
                    continue;
                }
            }
            float _1293 = _1330 * 0.36000001430511474609375;
            float _769 = fast::max(_1116, _1175) - _1057;
            float _777 = fast::max(_1234, _1293) - _1057;
            float _1331;
            if (_769 > 9.9999999747524270787835121154785e-07)
            {
                _1331 = fast::clamp((0.5 * (_1116 - _1175)) / _769, -0.5, 0.5);
            }
            else
            {
                _1331 = 0.0;
            }
            float _1332;
            if (_777 > 9.9999999747524270787835121154785e-07)
            {
                _1332 = fast::clamp((0.5 * (_1234 - _1293)) / _777, -0.5, 0.5);
            }
            else
            {
                _1332 = 0.0;
            }
            float4 _818 = float4((_1315 + (float2(_1331, _1332) * _502)) / _502, 0.0, 0.0);
            _196.write(_818, uint2(_631));
            _1372 = _818;
            break;
        } while(false);
        _563.write(_1372, uint2(_463));
        break;
    } while(false);
}

