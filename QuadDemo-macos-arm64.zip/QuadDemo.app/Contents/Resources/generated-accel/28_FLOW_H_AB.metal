#pragma clang diagnostic ignored "-Wmissing-prototypes"
#pragma clang diagnostic ignored "-Wmissing-braces"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template<typename T, size_t Num>
struct spvUnsafeArray
{
    T elements[Num ? Num : 1];
    
    thread T& operator [] (size_t pos) thread
    {
        return elements[pos];
    }
    constexpr const thread T& operator [] (size_t pos) const thread
    {
        return elements[pos];
    }
    
    device T& operator [] (size_t pos) device
    {
        return elements[pos];
    }
    constexpr const device T& operator [] (size_t pos) const device
    {
        return elements[pos];
    }
    
    constexpr const constant T& operator [] (size_t pos) const constant
    {
        return elements[pos];
    }
    
    threadgroup T& operator [] (size_t pos) threadgroup
    {
        return elements[pos];
    }
    constexpr const threadgroup T& operator [] (size_t pos) const threadgroup
    {
        return elements[pos];
    }
};

template <typename ImageT>
void spvImageFence(ImageT img) { img.fence(); }

struct _175
{
    float2 _m0;
    float2 _m1;
    float4 _m2[2];
    int _m3;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _175& _177 [[buffer(3)]], texture2d<float> _20 [[texture(0)]], texture2d<float, access::read_write> _47 [[texture(1)]], texture2d<float, access::write> _246 [[texture(2)]], sampler _20Smplr [[sampler(0)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _169 = int2(gl_GlobalInvocationID.xy);
        bool _182 = _169.x >= int(_177._m0.x);
        bool _193;
        if (!_182)
        {
            _193 = _169.y >= int(_177._m0.y);
        }
        else
        {
            _193 = _182;
        }
        if (_193)
        {
            break;
        }
        float2 _206 = (float2(_169) + float2(0.5)) / _177._m0;
        float2 _212 = float2(1.0) / _177._m1;
        float4 _396;
        do
        {
            int2 _284 = int2(_206 * _177._m1);
            if (_177._m3 == 0)
            {
                spvImageFence(_47);
                _396 = _47.read(uint2(_284));
                break;
            }
            int _383;
            _383 = -1;
            spvUnsafeArray<float2, 9> _270;
            int _394;
            for (int _395 = 0; _383 <= 1; _383++, _395 = _394)
            {
                _394 = _395;
                for (int _392 = -1; _392 <= 1; )
                {
                    _270[_394] = _20.sample(_20Smplr, (_206 + (float2(float(_392), float(_383)) * _212)), level(0.0)).xy;
                    _394++;
                    _392++;
                    continue;
                }
            }
            int _384;
            float2 _385;
            _385 = _270[4];
            _384 = 0;
            float _406;
            float2 _397;
            for (float _389 = 1000000015047466219876688855040.0; _384 < 9; _389 = _406, _385 = _397, _384++)
            {
                float _387;
                _387 = 0.0;
                for (int _386 = 0; _386 < 9; )
                {
                    _387 += length(_270[_384] - _270[_386]);
                    _386++;
                    continue;
                }
                bool _354 = _387 < (_389 * 0.99989998340606689453125);
                if (_354)
                {
                    _397 = _270[_384];
                }
                else
                {
                    _397 = _385;
                }
                _406 = _354 ? _387 : _389;
            }
            float4 _368 = float4(_385, 0.0, 0.0);
            _47.write(_368, uint2(_284));
            _396 = _368;
            break;
        } while(false);
        _246.write(_396, uint2(_169));
        break;
    } while(false);
}

