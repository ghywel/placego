#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct _178
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float4 _m5[2];
    int _m6;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);
constant bool _450 = {};

kernel void main0(constant _178& _180 [[buffer(5)]], texture2d<float> _36 [[texture(0)]], texture2d<float> _43 [[texture(1)]], texture2d<float, access::write> _281 [[texture(4)]], sampler _36Smplr [[sampler(0)]], sampler _43Smplr [[sampler(1)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _172 = int2(gl_GlobalInvocationID.xy);
        bool _185 = _172.x >= int(_180._m0.x);
        bool _196;
        if (!_185)
        {
            _196 = _172.y >= int(_180._m0.y);
        }
        else
        {
            _196 = _185;
        }
        if (_196)
        {
            break;
        }
        float2 _209 = (float2(_172) + float2(0.5)) / _180._m0;
        float2 _215 = float2(1.0) / _180._m1;
        bool _330 = abs(dot(_36.sample(_36Smplr, _209, level(0.0)).xyz, float3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)) - dot(_43.sample(_43Smplr, _209, level(0.0)).xyz, float3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625))) > 0.07999999821186065673828125;
        bool _312;
        if (_330)
        {
            bool _446;
            do
            {
                float _425 = dot(_43.sample(_43Smplr, _209, level(0.0)).xyz, float3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625));
                bool _441;
                bool _445;
                bool _447;
                bool _451;
                int _438 = -1;
                bool _443 = false;
                bool _448;
                for (;;)
                {
                    if (_438 <= 1)
                    {
                        int _439 = -1;
                        for (;;)
                        {
                            if (_439 <= 1)
                            {
                                if ((_439 == 0) && (_438 == 0))
                                {
                                    int _404 = _439 + 1;
                                    _439 = _404;
                                    continue;
                                }
                                if (abs(dot(_43.sample(_43Smplr, (_209 + (float2(float(_439), float(_438)) * _215)), level(0.0)).xyz, float3(0.2989999949932098388671875, 0.58700001239776611328125, 0.114000000059604644775390625)) - _425) > 0.100000001490116119384765625)
                                {
                                    _451 = true;
                                    _441 = true;
                                    break;
                                }
                                int _404 = _439 + 1;
                                _439 = _404;
                                continue;
                            }
                            else
                            {
                                _451 = _448;
                                _441 = _443;
                                break;
                            }
                        }
                        if (_441)
                        {
                            _447 = _451;
                            _445 = _441;
                            break;
                        }
                        _443 = _441;
                        _438++;
                        _448 = _451;
                        continue;
                    }
                    else
                    {
                        _447 = _448;
                        _445 = _443;
                        break;
                    }
                }
                if (_445)
                {
                    _446 = _447;
                    break;
                }
                _446 = false;
                break;
            } while(false);
            _312 = _446;
        }
        else
        {
            _312 = _330;
        }
        _281.write(float4(float(_312), 0.0, 0.0, 0.0), uint2(_172));
        break;
    } while(false);
}

