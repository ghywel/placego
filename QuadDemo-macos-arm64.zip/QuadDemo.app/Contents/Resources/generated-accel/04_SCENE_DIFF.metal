#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

struct _110
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float4 _m3[2];
    int _m4;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _110& _112 [[buffer(3)]], texture2d<float> _23 [[texture(0)]], texture2d<float> _30 [[texture(1)]], texture2d<float, access::write> _196 [[texture(2)]], sampler _23Smplr [[sampler(0)]], sampler _30Smplr [[sampler(1)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _105 = int2(gl_GlobalInvocationID.xy);
        bool _117 = _105.x >= int(_112._m0.x);
        bool _128;
        if (!_117)
        {
            _128 = _105.y >= int(_112._m0.y);
        }
        else
        {
            _128 = _117;
        }
        if (_128)
        {
            break;
        }
        int _269;
        float _270;
        _270 = 0.0;
        _269 = 0;
        float _273;
        for (; _269 < 24; _270 = _273, _269++)
        {
            _273 = _270;
            for (int _271 = 0; _271 < 24; )
            {
                float2 _235 = (float2(float(_271), float(_269)) + float2(0.5)) * float2(0.0416666679084300994873046875);
                _273 += abs(_23.sample(_23Smplr, _235, level(0.0)).x - _30.sample(_30Smplr, _235, level(0.0)).x);
                _271++;
                continue;
            }
        }
        _196.write(float4(_270 * 0.001736111124046146869659423828125, 0.0, 0.0, 0.0), uint2(_105));
        break;
    } while(false);
}

