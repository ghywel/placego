#pragma clang diagnostic ignored "-Wmissing-prototypes"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template <typename ImageT>
void spvImageFence(ImageT img) { img.fence(); }

struct _308
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float4 _m5[2];
    int _m6;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _308& _310 [[buffer(6)]], texture2d<float> _32 [[texture(2)]], texture2d<float> _39 [[texture(3)]], texture2d<float, access::read_write> _169 [[texture(4)]], texture2d<float, access::write> _405 [[texture(5)]], sampler _32Smplr [[sampler(2)]], sampler _39Smplr [[sampler(3)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _303 = int2(gl_GlobalInvocationID.xy);
        bool _315 = _303.x >= int(_310._m0.x);
        bool _326;
        if (!_315)
        {
            _326 = _303.y >= int(_310._m0.y);
        }
        else
        {
            _326 = _315;
        }
        if (_326)
        {
            break;
        }
        float2 _338 = (float2(_303) + float2(0.5)) / _310._m0;
        float2 _343 = float2(1.0) / _310._m1;
        float4 _759;
        do
        {
            int2 _450 = int2(_338 * _310._m1);
            if (_310._m6 == 0)
            {
                spvImageFence(_169);
                _759 = _169.read(uint2(_450));
                break;
            }
            int _721;
            float _722;
            float _723;
            _723 = 1.0;
            _722 = 0.0;
            _721 = -2;
            float _757;
            float _758;
            for (; _721 <= 2; _723 = _757, _722 = _758, _721++)
            {
                _758 = _722;
                _757 = _723;
                for (int _755 = -2; _755 <= 2; )
                {
                    float4 _601 = _32.sample(_32Smplr, (_338 + (float2(float(_755), float(_721)) * _343)), level(0.0));
                    float _579 = _601.x;
                    _758 = fast::max(_758, _579);
                    _757 = fast::min(_757, _579);
                    _755++;
                    continue;
                }
            }
            if ((_722 - _723) < 0.0199999995529651641845703125)
            {
                _169.write(float4(0.0), uint2(_450));
                _759 = float4(0.0);
                break;
            }
            int _724;
            float _725;
            _725 = 0.0;
            _724 = -1;
            float _754;
            for (; _724 <= 1; _725 = _754, _724++)
            {
                _754 = _725;
                for (int _752 = -1; _752 <= 1; )
                {
                    float2 _629 = _338 + (float2(float(_752), float(_724)) * _343);
                    _754 += abs(_32.sample(_32Smplr, _629, level(0.0)).x - _39.sample(_39Smplr, _629, level(0.0)).x);
                    _752++;
                    continue;
                }
            }
            float2 _727;
            _727 = float2(0.0);
            float _534;
            float2 _730;
            float _743;
            int _726 = 0;
            float _732 = 0.75;
            float _744 = _725;
            for (; _726 < 5; _732 = _534, _727 = _730, _726++, _744 = _743)
            {
                _730 = _727;
                _743 = _744;
                float _742;
                float2 _761;
                for (int _729 = -1; _729 <= 1; _730 = _761, _729++, _743 = _742)
                {
                    _742 = _743;
                    _761 = _730;
                    float2 _762;
                    float _783;
                    for (int _734 = -1; _734 <= 1; _742 = _783, _734++, _761 = _762)
                    {
                        if ((_734 == 0) && (_729 == 0))
                        {
                            _783 = _742;
                            _762 = _761;
                            continue;
                        }
                        float2 _504 = _727 + ((float2(float(_734), float(_729)) * _732) * _343);
                        float2 _507 = _338 + _504;
                        int _739;
                        float _740;
                        _740 = 0.0;
                        _739 = -1;
                        float _747;
                        for (; _739 <= 1; _740 = _747, _739++)
                        {
                            _747 = _740;
                            for (int _745 = -1; _745 <= 1; )
                            {
                                float2 _684 = float2(float(_745), float(_739)) * _343;
                                _747 += abs(_32.sample(_32Smplr, (_338 + _684), level(0.0)).x - _39.sample(_39Smplr, (_507 + _684), level(0.0)).x);
                                _745++;
                                continue;
                            }
                        }
                        float _515 = _740 + (0.0599999986588954925537109375 * length(_504 / _343));
                        bool _519 = _515 < (_742 * 0.99989998340606689453125);
                        _783 = _519 ? _515 : _742;
                        _762 = select(_761, _504, bool2(_519));
                    }
                }
                _534 = _732 * 0.5;
            }
            float4 _544 = float4(_727 / _343, 0.0, 0.0);
            _169.write(_544, uint2(_450));
            _759 = _544;
            break;
        } while(false);
        _405.write(_759, uint2(_303));
        break;
    } while(false);
}

