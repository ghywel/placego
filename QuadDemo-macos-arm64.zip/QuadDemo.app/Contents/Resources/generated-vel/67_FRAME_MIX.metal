#pragma clang diagnostic ignored "-Wmissing-prototypes"
#pragma clang diagnostic ignored "-Wmissing-braces"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template<typename T, size_t Num>
struct spvUnsafeArray
{
    T elements[Num ? Num : 1];
    
    thread T& operator [] (size_t pos) thread
    {
        return elements[pos];
    }
    constexpr const thread T& operator [] (size_t pos) const thread
    {
        return elements[pos];
    }
    
    device T& operator [] (size_t pos) device
    {
        return elements[pos];
    }
    constexpr const device T& operator [] (size_t pos) const device
    {
        return elements[pos];
    }
    
    constexpr const constant T& operator [] (size_t pos) const constant
    {
        return elements[pos];
    }
    
    threadgroup T& operator [] (size_t pos) threadgroup
    {
        return elements[pos];
    }
    constexpr const threadgroup T& operator [] (size_t pos) const threadgroup
    {
        return elements[pos];
    }
};

// Implementation of signed integer mod accurate to SPIR-V specification
template<typename Tx, typename Ty>
inline Tx spvSMod(Tx x, Ty y)
{
    Tx remainder = x - y * (x / y);
    return select(Tx(remainder + y), remainder, remainder == 0 || (x >= 0) == (y >= 0));
}

struct _1149
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float2 _m5;
    float2 _m6;
    float2 _m7;
    float2 _m8;
    float2 _m9;
    float2 _m10;
    float2 _m11;
    float2 _m12;
    float2 _m13;
    float2 _m14;
    float2 _m15;
    float2 _m16;
    float4 _m17[2];
    int _m18;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _1149& _1151 [[buffer(17)]], texture2d<float> _74 [[texture(0)]], texture2d<float> _81 [[texture(1)]], texture2d<float> _87 [[texture(2)]], texture2d<float> _93 [[texture(3)]], texture2d<float> _99 [[texture(4)]], texture2d<float> _105 [[texture(5)]], texture2d<float> _111 [[texture(6)]], texture2d<float> _117 [[texture(7)]], texture2d<float> _123 [[texture(8)]], texture2d<float> _129 [[texture(9)]], texture2d<float, access::write> _1362 [[texture(16)]], sampler _74Smplr [[sampler(0)]], sampler _81Smplr [[sampler(1)]], sampler _87Smplr [[sampler(2)]], sampler _93Smplr [[sampler(3)]], sampler _99Smplr [[sampler(4)]], sampler _105Smplr [[sampler(5)]], sampler _111Smplr [[sampler(6)]], sampler _117Smplr [[sampler(7)]], sampler _123Smplr [[sampler(8)]], sampler _129Smplr [[sampler(9)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _1145 = int2(gl_GlobalInvocationID.xy);
        bool _1156 = _1145.x >= int(_1151._m0.x);
        bool _1166;
        if (!_1156)
        {
            _1166 = _1145.y >= int(_1151._m0.y);
        }
        else
        {
            _1166 = _1156;
        }
        if (_1166)
        {
            break;
        }
        float2 _1178 = (float2(_1145) + float2(0.5)) / _1151._m0;
        float2 _1184 = float2(1.0) / _1151._m1;
        spvUnsafeArray<float, 8> _235;
        for (int _2173 = 0; _2173 < 8; )
        {
            _235[_2173] = _1151._m17[_2173 / 4][spvSMod(_2173, 4)];
            _2173++;
            continue;
        }
        float4 _2185;
        do
        {
            int _2189 = (_235[2] <= 0.0) ? 2 : int(_235[1] <= 0.0);
            int _1496 = _2189 + 1;
            bool _1508 = _2189 == 0;
            float2 _2177;
            if (_1508)
            {
                _2177 = _117.sample(_117Smplr, _1178, level(0.0)).xy;
            }
            else
            {
                float2 _2176;
                if (_2189 == 1)
                {
                    _2176 = _123.sample(_123Smplr, _1178, level(0.0)).xy;
                }
                else
                {
                    _2176 = _129.sample(_129Smplr, _1178, level(0.0)).xy;
                }
                _2177 = _2176;
            }
            float _2180;
            if (_1508)
            {
                _2180 = _99.sample(_99Smplr, float2(0.5), level(0.0)).x;
            }
            else
            {
                _2180 = (_2189 == 1) ? _105.sample(_105Smplr, float2(0.5), level(0.0)).x : _111.sample(_111Smplr, float2(0.5), level(0.0)).x;
            }
            if (_2180 > 0.125)
            {
                float4 _2184;
                if (fast::clamp((-_235[_2189]) / (_235[_1496] - _235[_2189]), 0.0, 1.0) < 0.5)
                {
                    float4 _2183;
                    do
                    {
                        if (_1508)
                        {
                            _2183 = _74.sample(_74Smplr, _1178, level(0.0));
                            break;
                        }
                        if (_2189 == 1)
                        {
                            _2183 = _81.sample(_81Smplr, _1178, level(0.0));
                            break;
                        }
                        if (_2189 == 2)
                        {
                            _2183 = _87.sample(_87Smplr, _1178, level(0.0));
                            break;
                        }
                        _2183 = _93.sample(_93Smplr, _1178, level(0.0));
                        break;
                    } while(false);
                    _2184 = _2183;
                }
                else
                {
                    float4 _2182;
                    do
                    {
                        if (_1496 == 0)
                        {
                            _2182 = _74.sample(_74Smplr, _1178, level(0.0));
                            break;
                        }
                        if (_1496 == 1)
                        {
                            _2182 = _81.sample(_81Smplr, _1178, level(0.0));
                            break;
                        }
                        if (_1496 == 2)
                        {
                            _2182 = _87.sample(_87Smplr, _1178, level(0.0));
                            break;
                        }
                        _2182 = _93.sample(_93Smplr, _1178, level(0.0));
                        break;
                    } while(false);
                    _2184 = _2182;
                }
                _2185 = _2184;
                break;
            }
            bool _1940 = _1178.x < (24.0 * _1184.x);
            bool _1949;
            if (_1940)
            {
                _1949 = _1178.y < (24.0 * _1184.y);
            }
            else
            {
                _1949 = _1940;
            }
            if (_1949)
            {
                _2185 = float4(1.0, 0.60000002384185791015625, 0.100000001490116119384765625, 1.0);
                break;
            }
            _2185 = float4(float2(0.5) + ((_2177 * 2.0) * 0.015625), 0.5, 1.0);
            break;
        } while(false);
        _1362.write(_2185, uint2(_1145));
        break;
    } while(false);
}

