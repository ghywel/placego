#pragma clang diagnostic ignored "-Wmissing-prototypes"
#pragma clang diagnostic ignored "-Wmissing-braces"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template<typename T, size_t Num>
struct spvUnsafeArray
{
    T elements[Num ? Num : 1];
    
    thread T& operator [] (size_t pos) thread
    {
        return elements[pos];
    }
    constexpr const thread T& operator [] (size_t pos) const thread
    {
        return elements[pos];
    }
    
    device T& operator [] (size_t pos) device
    {
        return elements[pos];
    }
    constexpr const device T& operator [] (size_t pos) const device
    {
        return elements[pos];
    }
    
    constexpr const constant T& operator [] (size_t pos) const constant
    {
        return elements[pos];
    }
    
    threadgroup T& operator [] (size_t pos) threadgroup
    {
        return elements[pos];
    }
    constexpr const threadgroup T& operator [] (size_t pos) const threadgroup
    {
        return elements[pos];
    }
};

// Implementation of signed integer mod accurate to SPIR-V specification
template<typename Tx, typename Ty>
inline Tx spvSMod(Tx x, Ty y)
{
    Tx remainder = x - y * (x / y);
    return select(Tx(remainder + y), remainder, remainder == 0 || (x >= 0) == (y >= 0));
}

// Returns the determinant of a 2x2 matrix.
static inline __attribute__((always_inline))
float spvDet2x2(float a1, float a2, float b1, float b2)
{
    return a1 * b2 - b1 * a2;
}

// Returns the inverse of a matrix, by using the algorithm of calculating the classical
// adjoint and dividing by the determinant. The contents of the matrix are changed.
static inline __attribute__((always_inline))
float3x3 spvInverse3x3(float3x3 m)
{
    float3x3 adj;	// The adjoint matrix (inverse after dividing by determinant)

    // Create the transpose of the cofactors, as the classical adjoint of the matrix.
    adj[0][0] =  spvDet2x2(m[1][1], m[1][2], m[2][1], m[2][2]);
    adj[0][1] = -spvDet2x2(m[0][1], m[0][2], m[2][1], m[2][2]);
    adj[0][2] =  spvDet2x2(m[0][1], m[0][2], m[1][1], m[1][2]);

    adj[1][0] = -spvDet2x2(m[1][0], m[1][2], m[2][0], m[2][2]);
    adj[1][1] =  spvDet2x2(m[0][0], m[0][2], m[2][0], m[2][2]);
    adj[1][2] = -spvDet2x2(m[0][0], m[0][2], m[1][0], m[1][2]);

    adj[2][0] =  spvDet2x2(m[1][0], m[1][1], m[2][0], m[2][1]);
    adj[2][1] = -spvDet2x2(m[0][0], m[0][1], m[2][0], m[2][1]);
    adj[2][2] =  spvDet2x2(m[0][0], m[0][1], m[1][0], m[1][1]);

    // Calculate the determinant as a combination of the cofactors of the first row.
    float det = (adj[0][0] * m[0][0]) + (adj[0][1] * m[1][0]) + (adj[0][2] * m[2][0]);

    // Divide the classical adjoint matrix by the determinant.
    // If determinant is zero, matrix is not invertable, so leave it unchanged.
    return (det != 0.0f) ? (adj * (1.0f / det)) : m;
}

struct _1131
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float2 _m5;
    float2 _m6;
    float2 _m7;
    float2 _m8;
    float2 _m9;
    float2 _m10;
    float2 _m11;
    float2 _m12;
    float2 _m13;
    float2 _m14;
    float2 _m15;
    float2 _m16;
    float4 _m17[2];
    int _m18;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _1131& _1133 [[buffer(17)]], texture2d<float> _74 [[texture(0)]], texture2d<float> _81 [[texture(1)]], texture2d<float> _87 [[texture(2)]], texture2d<float> _93 [[texture(3)]], texture2d<float> _99 [[texture(4)]], texture2d<float> _105 [[texture(5)]], texture2d<float> _111 [[texture(6)]], texture2d<float> _135 [[texture(10)]], texture2d<float> _141 [[texture(11)]], texture2d<float> _147 [[texture(12)]], texture2d<float> _153 [[texture(13)]], texture2d<float> _159 [[texture(14)]], texture2d<float> _165 [[texture(15)]], texture2d<float, access::write> _1344 [[texture(16)]], sampler _74Smplr [[sampler(0)]], sampler _81Smplr [[sampler(1)]], sampler _87Smplr [[sampler(2)]], sampler _93Smplr [[sampler(3)]], sampler _99Smplr [[sampler(4)]], sampler _105Smplr [[sampler(5)]], sampler _111Smplr [[sampler(6)]], sampler _135Smplr [[sampler(10)]], sampler _141Smplr [[sampler(11)]], sampler _147Smplr [[sampler(12)]], sampler _153Smplr [[sampler(13)]], sampler _159Smplr [[sampler(14)]], sampler _165Smplr [[sampler(15)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _1127 = int2(gl_GlobalInvocationID.xy);
        bool _1138 = _1127.x >= int(_1133._m0.x);
        bool _1148;
        if (!_1138)
        {
            _1148 = _1127.y >= int(_1133._m0.y);
        }
        else
        {
            _1148 = _1138;
        }
        if (_1148)
        {
            break;
        }
        float2 _1160 = (float2(_1127) + float2(0.5)) / _1133._m0;
        float2 _1166 = float2(1.0) / _1133._m1;
        spvUnsafeArray<float, 8> _230;
        for (int _2159 = 0; _2159 < 8; )
        {
            _230[_2159] = _1133._m17[_2159 / 4][spvSMod(_2159, 4)];
            _2159++;
            continue;
        }
        float4 _2188;
        do
        {
            int _2195 = (_230[2] <= 0.0) ? 2 : int(_230[1] <= 0.0);
            int _1477 = _2195 + 1;
            float _1482 = _230[_1477] - _230[_2195];
            float _1487 = fast::clamp((-_230[_2195]) / _1482, 0.0, 1.0);
            float4 _1966 = _99.sample(_99Smplr, float2(0.5), level(0.0));
            float _1513 = _1966.x;
            float4 _1971 = _105.sample(_105Smplr, float2(0.5), level(0.0));
            float _1515 = _1971.x;
            float4 _1976 = _111.sample(_111Smplr, float2(0.5), level(0.0));
            float _1517 = _1976.x;
            bool _1519 = _2195 == 0;
            float _2162;
            if (_1519)
            {
                _2162 = _1513;
            }
            else
            {
                _2162 = (_2195 == 1) ? _1515 : _1517;
            }
            if (_2162 > 0.125)
            {
                float4 _2187;
                if (_1487 < 0.5)
                {
                    float4 _2186;
                    do
                    {
                        if (_1519)
                        {
                            _2186 = _74.sample(_74Smplr, _1160, level(0.0));
                            break;
                        }
                        if (_2195 == 1)
                        {
                            _2186 = _81.sample(_81Smplr, _1160, level(0.0));
                            break;
                        }
                        if (_2195 == 2)
                        {
                            _2186 = _87.sample(_87Smplr, _1160, level(0.0));
                            break;
                        }
                        _2186 = _93.sample(_93Smplr, _1160, level(0.0));
                        break;
                    } while(false);
                    _2187 = _2186;
                }
                else
                {
                    float4 _2185;
                    do
                    {
                        if (_1477 == 0)
                        {
                            _2185 = _74.sample(_74Smplr, _1160, level(0.0));
                            break;
                        }
                        if (_1477 == 1)
                        {
                            _2185 = _81.sample(_81Smplr, _1160, level(0.0));
                            break;
                        }
                        if (_1477 == 2)
                        {
                            _2185 = _87.sample(_87Smplr, _1160, level(0.0));
                            break;
                        }
                        _2185 = _93.sample(_93Smplr, _1160, level(0.0));
                        break;
                    } while(false);
                    _2187 = _2185;
                }
                _2188 = _2187;
                break;
            }
            bool _1561 = clamp((_1487 <= 0.5) ? _2195 : _1477, 1, 2) == 1;
            float _2165;
            float _2166;
            float _2167;
            float2 _2168;
            float2 _2169;
            float2 _2170;
            float _2172;
            float _2174;
            float _2176;
            float _2179;
            if (_1561)
            {
                float2 _1657 = _141.sample(_141Smplr, _1160, level(0.0)).xy * _1166;
                float2 _1662 = _147.sample(_147Smplr, _1160, level(0.0)).xy * _1166;
                float2 _1665 = _1160 + _1662;
                float2 _1669 = _159.sample(_159Smplr, _1665, level(0.0)).xy * _1166;
                float2 _1672 = _1662 + _1669;
                float _1685 = length(_1166);
                float _1700 = length(_1662 + (_153.sample(_153Smplr, _1665, level(0.0)).xy * _1166)) / _1685;
                _2179 = fast::max(_1513, _1515);
                _2176 = fast::max(_1700, length(_1669 + (_165.sample(_165Smplr, (_1160 + _1672), level(0.0)).xy * _1166)) / _1685);
                _2174 = _1700;
                _2172 = length(_1657 + (_135.sample(_135Smplr, (_1160 + _1657), level(0.0)).xy * _1166)) / _1685;
                _2170 = _1672;
                _2169 = _1662;
                _2168 = _1657;
                _2167 = (_230[3] - _230[1]) / _1482;
                _2166 = (_230[2] - _230[1]) / _1482;
                _2165 = (_230[0] - _230[1]) / _1482;
            }
            else
            {
                float2 _1567 = _153.sample(_153Smplr, _1160, level(0.0)).xy * _1166;
                float2 _1572 = _159.sample(_159Smplr, _1160, level(0.0)).xy * _1166;
                float2 _1575 = _1160 + _1567;
                float2 _1579 = _141.sample(_141Smplr, _1575, level(0.0)).xy * _1166;
                float2 _1582 = _1567 + _1579;
                float _1595 = length(_1166);
                float _1596 = length(_1567 + (_147.sample(_147Smplr, _1575, level(0.0)).xy * _1166)) / _1595;
                _2179 = fast::max(_1515, _1517);
                _2176 = fast::max(_1596, length(_1579 + (_135.sample(_135Smplr, (_1160 + _1582), level(0.0)).xy * _1166)) / _1595);
                _2174 = length(_1572 + (_165.sample(_165Smplr, (_1160 + _1572), level(0.0)).xy * _1166)) / _1595;
                _2172 = _1596;
                _2170 = _1582;
                _2169 = _1572;
                _2168 = _1567;
                _2167 = (_230[0] - _230[2]) / _1482;
                _2166 = (_230[3] - _230[2]) / _1482;
                _2165 = (_230[1] - _230[2]) / _1482;
            }
            float _1750 = _2165 * _2165;
            float _1753 = _2166 * _2166;
            float _1756 = _2167 * _2167;
            float3x3 _1789 = float3x3(float3(_2165, _2166, _2167), float3(_1750, _1753, _1756) * 0.5, float3(_1750 * _2165, _1753 * _2166, _1756 * _2167) * float3(0.16666667163372039794921875));
            float2 _2177;
            if (abs(determinant(_1789)) > 9.9999997473787516355514526367188e-05)
            {
                float3x3 _1796 = spvInverse3x3(_1789);
                _2177 = float2((_1796 * float3(_2168.x, _2169.x, _2170.x)).z, (_1796 * float3(_2168.y, _2169.y, _2170.y)).z);
            }
            else
            {
                _2177 = float2(0.0);
            }
            float2 _2182;
            if (_2179 > 0.125)
            {
                _2182 = float2(0.0);
            }
            else
            {
                _2182 = select(_2177 * (1.0 - smoothstep(2.0, 5.0, fast::max(fast::max(_2172, _2174), _2176))), float2(0.0), bool2((_1561 ? _1517 : _1513) > 0.125));
            }
            float2 _1864 = _1166 * 8.0;
            bool _1920 = _1160.x < (24.0 * _1166.x);
            bool _1929;
            if (_1920)
            {
                _1929 = _1160.y < (24.0 * _1166.y);
            }
            else
            {
                _1929 = _1920;
            }
            if (_1929)
            {
                _2188 = float4(1.0, 0.20000000298023223876953125, 1.0, 1.0);
                break;
            }
            _2188 = float4(float2(0.5) + ((fast::clamp(_2182, -_1864, _1864) / _1166) * 0.0625), 0.5, 1.0);
            break;
        } while(false);
        _1344.write(_2188, uint2(_1127));
        break;
    } while(false);
}

