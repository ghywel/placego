#pragma clang diagnostic ignored "-Wmissing-prototypes"
#pragma clang diagnostic ignored "-Wmissing-braces"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template<typename T, size_t Num>
struct spvUnsafeArray
{
    T elements[Num ? Num : 1];
    
    thread T& operator [] (size_t pos) thread
    {
        return elements[pos];
    }
    constexpr const thread T& operator [] (size_t pos) const thread
    {
        return elements[pos];
    }
    
    device T& operator [] (size_t pos) device
    {
        return elements[pos];
    }
    constexpr const device T& operator [] (size_t pos) const device
    {
        return elements[pos];
    }
    
    constexpr const constant T& operator [] (size_t pos) const constant
    {
        return elements[pos];
    }
    
    threadgroup T& operator [] (size_t pos) threadgroup
    {
        return elements[pos];
    }
    constexpr const threadgroup T& operator [] (size_t pos) const threadgroup
    {
        return elements[pos];
    }
};

// Implementation of signed integer mod accurate to SPIR-V specification
template<typename Tx, typename Ty>
inline Tx spvSMod(Tx x, Ty y)
{
    Tx remainder = x - y * (x / y);
    return select(Tx(remainder + y), remainder, remainder == 0 || (x >= 0) == (y >= 0));
}

// Returns the determinant of a 2x2 matrix.
static inline __attribute__((always_inline))
float spvDet2x2(float a1, float a2, float b1, float b2)
{
    return a1 * b2 - b1 * a2;
}

// Returns the inverse of a matrix, by using the algorithm of calculating the classical
// adjoint and dividing by the determinant. The contents of the matrix are changed.
static inline __attribute__((always_inline))
float3x3 spvInverse3x3(float3x3 m)
{
    float3x3 adj;	// The adjoint matrix (inverse after dividing by determinant)

    // Create the transpose of the cofactors, as the classical adjoint of the matrix.
    adj[0][0] =  spvDet2x2(m[1][1], m[1][2], m[2][1], m[2][2]);
    adj[0][1] = -spvDet2x2(m[0][1], m[0][2], m[2][1], m[2][2]);
    adj[0][2] =  spvDet2x2(m[0][1], m[0][2], m[1][1], m[1][2]);

    adj[1][0] = -spvDet2x2(m[1][0], m[1][2], m[2][0], m[2][2]);
    adj[1][1] =  spvDet2x2(m[0][0], m[0][2], m[2][0], m[2][2]);
    adj[1][2] = -spvDet2x2(m[0][0], m[0][2], m[1][0], m[1][2]);

    adj[2][0] =  spvDet2x2(m[1][0], m[1][1], m[2][0], m[2][1]);
    adj[2][1] = -spvDet2x2(m[0][0], m[0][1], m[2][0], m[2][1]);
    adj[2][2] =  spvDet2x2(m[0][0], m[0][1], m[1][0], m[1][1]);

    // Calculate the determinant as a combination of the cofactors of the first row.
    float det = (adj[0][0] * m[0][0]) + (adj[0][1] * m[1][0]) + (adj[0][2] * m[2][0]);

    // Divide the classical adjoint matrix by the determinant.
    // If determinant is zero, matrix is not invertable, so leave it unchanged.
    return (det != 0.0f) ? (adj * (1.0f / det)) : m;
}

struct _1130
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float2 _m5;
    float2 _m6;
    float2 _m7;
    float2 _m8;
    float2 _m9;
    float2 _m10;
    float2 _m11;
    float2 _m12;
    float2 _m13;
    float2 _m14;
    float2 _m15;
    float2 _m16;
    float4 _m17[2];
    int _m18;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _1130& _1132 [[buffer(17)]], texture2d<float> _74 [[texture(0)]], texture2d<float> _81 [[texture(1)]], texture2d<float> _87 [[texture(2)]], texture2d<float> _93 [[texture(3)]], texture2d<float> _99 [[texture(4)]], texture2d<float> _105 [[texture(5)]], texture2d<float> _111 [[texture(6)]], texture2d<float> _117 [[texture(7)]], texture2d<float> _123 [[texture(8)]], texture2d<float> _129 [[texture(9)]], texture2d<float> _135 [[texture(10)]], texture2d<float> _141 [[texture(11)]], texture2d<float> _147 [[texture(12)]], texture2d<float> _153 [[texture(13)]], texture2d<float> _159 [[texture(14)]], texture2d<float> _165 [[texture(15)]], texture2d<float, access::write> _1343 [[texture(16)]], sampler _74Smplr [[sampler(0)]], sampler _81Smplr [[sampler(1)]], sampler _87Smplr [[sampler(2)]], sampler _93Smplr [[sampler(3)]], sampler _99Smplr [[sampler(4)]], sampler _105Smplr [[sampler(5)]], sampler _111Smplr [[sampler(6)]], sampler _117Smplr [[sampler(7)]], sampler _123Smplr [[sampler(8)]], sampler _129Smplr [[sampler(9)]], sampler _135Smplr [[sampler(10)]], sampler _141Smplr [[sampler(11)]], sampler _147Smplr [[sampler(12)]], sampler _153Smplr [[sampler(13)]], sampler _159Smplr [[sampler(14)]], sampler _165Smplr [[sampler(15)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _1126 = int2(gl_GlobalInvocationID.xy);
        bool _1137 = _1126.x >= int(_1132._m0.x);
        bool _1147;
        if (!_1137)
        {
            _1147 = _1126.y >= int(_1132._m0.y);
        }
        else
        {
            _1147 = _1137;
        }
        if (_1147)
        {
            break;
        }
        float2 _1159 = (float2(_1126) + float2(0.5)) / _1132._m0;
        float2 _1165 = float2(1.0) / _1132._m1;
        spvUnsafeArray<float, 8> _229;
        for (int _2248 = 0; _2248 < 8; )
        {
            _229[_2248] = _1132._m17[_2248 / 4][spvSMod(_2248, 4)];
            _2248++;
            continue;
        }
        float4 _2295;
        do
        {
            int _2302 = (_229[2] <= 0.0) ? 2 : int(_229[1] <= 0.0);
            int _1476 = _2302 + 1;
            float _1481 = _229[_1476] - _229[_2302];
            float _1486 = fast::clamp((-_229[_2302]) / _1481, 0.0, 1.0);
            bool _1488 = _2302 == 0;
            float2 _2252;
            if (_1488)
            {
                _2252 = _117.sample(_117Smplr, _1159, level(0.0)).xy;
            }
            else
            {
                float2 _2251;
                if (_2302 == 1)
                {
                    _2251 = _123.sample(_123Smplr, _1159, level(0.0)).xy;
                }
                else
                {
                    _2251 = _129.sample(_129Smplr, _1159, level(0.0)).xy;
                }
                _2252 = _2251;
            }
            float2 _1510 = (_2252 * 2.0) * _1165;
            float4 _1960 = _99.sample(_99Smplr, float2(0.5), level(0.0));
            float _1512 = _1960.x;
            float4 _1965 = _105.sample(_105Smplr, float2(0.5), level(0.0));
            float _1514 = _1965.x;
            float4 _1970 = _111.sample(_111Smplr, float2(0.5), level(0.0));
            float _1516 = _1970.x;
            float _2255;
            if (_1488)
            {
                _2255 = _1512;
            }
            else
            {
                _2255 = (_2302 == 1) ? _1514 : _1516;
            }
            if (_2255 > 0.125)
            {
                float4 _2294;
                if (_1486 < 0.5)
                {
                    float4 _2293;
                    do
                    {
                        if (_1488)
                        {
                            _2293 = _74.sample(_74Smplr, _1159, level(0.0));
                            break;
                        }
                        if (_2302 == 1)
                        {
                            _2293 = _81.sample(_81Smplr, _1159, level(0.0));
                            break;
                        }
                        if (_2302 == 2)
                        {
                            _2293 = _87.sample(_87Smplr, _1159, level(0.0));
                            break;
                        }
                        _2293 = _93.sample(_93Smplr, _1159, level(0.0));
                        break;
                    } while(false);
                    _2294 = _2293;
                }
                else
                {
                    float4 _2292;
                    do
                    {
                        if (_1476 == 0)
                        {
                            _2292 = _74.sample(_74Smplr, _1159, level(0.0));
                            break;
                        }
                        if (_1476 == 1)
                        {
                            _2292 = _81.sample(_81Smplr, _1159, level(0.0));
                            break;
                        }
                        if (_1476 == 2)
                        {
                            _2292 = _87.sample(_87Smplr, _1159, level(0.0));
                            break;
                        }
                        _2292 = _93.sample(_93Smplr, _1159, level(0.0));
                        break;
                    } while(false);
                    _2294 = _2292;
                }
                _2295 = _2294;
                break;
            }
            int _1555 = clamp((_1486 <= 0.5) ? _2302 : _1476, 1, 2);
            bool _1560 = _1555 == 1;
            float _2259;
            float _2260;
            float _2261;
            float2 _2262;
            float2 _2263;
            float2 _2264;
            float _2266;
            float _2268;
            float _2270;
            float _2274;
            if (_1560)
            {
                float2 _1656 = _141.sample(_141Smplr, _1159, level(0.0)).xy * _1165;
                float2 _1661 = _147.sample(_147Smplr, _1159, level(0.0)).xy * _1165;
                float2 _1664 = _1159 + _1661;
                float2 _1668 = _159.sample(_159Smplr, _1664, level(0.0)).xy * _1165;
                float2 _1671 = _1661 + _1668;
                float _1684 = length(_1165);
                float _1699 = length(_1661 + (_153.sample(_153Smplr, _1664, level(0.0)).xy * _1165)) / _1684;
                _2274 = fast::max(_1512, _1514);
                _2270 = fast::max(_1699, length(_1668 + (_165.sample(_165Smplr, (_1159 + _1671), level(0.0)).xy * _1165)) / _1684);
                _2268 = _1699;
                _2266 = length(_1656 + (_135.sample(_135Smplr, (_1159 + _1656), level(0.0)).xy * _1165)) / _1684;
                _2264 = _1671;
                _2263 = _1661;
                _2262 = _1656;
                _2261 = (_229[3] - _229[1]) / _1481;
                _2260 = (_229[2] - _229[1]) / _1481;
                _2259 = (_229[0] - _229[1]) / _1481;
            }
            else
            {
                float2 _1566 = _153.sample(_153Smplr, _1159, level(0.0)).xy * _1165;
                float2 _1571 = _159.sample(_159Smplr, _1159, level(0.0)).xy * _1165;
                float2 _1574 = _1159 + _1566;
                float2 _1578 = _141.sample(_141Smplr, _1574, level(0.0)).xy * _1165;
                float2 _1581 = _1566 + _1578;
                float _1594 = length(_1165);
                float _1595 = length(_1566 + (_147.sample(_147Smplr, _1574, level(0.0)).xy * _1165)) / _1594;
                _2274 = fast::max(_1514, _1516);
                _2270 = fast::max(_1595, length(_1578 + (_135.sample(_135Smplr, (_1159 + _1581), level(0.0)).xy * _1165)) / _1594);
                _2268 = length(_1571 + (_165.sample(_165Smplr, (_1159 + _1571), level(0.0)).xy * _1165)) / _1594;
                _2266 = _1595;
                _2264 = _1581;
                _2263 = _1571;
                _2262 = _1566;
                _2261 = (_229[0] - _229[2]) / _1481;
                _2260 = (_229[3] - _229[2]) / _1481;
                _2259 = (_229[1] - _229[2]) / _1481;
            }
            float _1749 = _2259 * _2259;
            float _1752 = _2260 * _2260;
            float _1755 = _2261 * _2261;
            float3x3 _1788 = float3x3(float3(_2259, _2260, _2261), float3(_1749, _1752, _1755) * 0.5, float3(_1749 * _2259, _1752 * _2260, _1755 * _2261) * float3(0.16666667163372039794921875));
            float2 _2271;
            float2 _2272;
            if (abs(determinant(_1788)) > 9.9999997473787516355514526367188e-05)
            {
                float3x3 _1795 = spvInverse3x3(_1788);
                float3 _1804 = _1795 * float3(_2262.x, _2263.x, _2264.x);
                float3 _1813 = _1795 * float3(_2262.y, _2263.y, _2264.y);
                _2272 = float2(_1804.z, _1813.z);
                _2271 = float2(_1804.y, _1813.y);
            }
            else
            {
                _2272 = float2(0.0);
                _2271 = float2(0.0);
            }
            float _1828 = fast::max(_2266, _2268);
            bool _1847 = _2274 > 0.125;
            float2 _2279;
            if (_1847)
            {
                _2279 = float2(0.0);
            }
            else
            {
                _2279 = select(_2272 * (1.0 - smoothstep(2.0, 5.0, fast::max(_1828, _2270))), float2(0.0), bool2((_1560 ? _1516 : _1512) > 0.125));
            }
            float2 _1856 = _1165 * 16.0;
            float2 _1861 = fast::clamp(select(_2271 * (1.0 - smoothstep(2.0, 5.0, _1828)), float2(0.0), bool2(_1847)), -_1856, _1856);
            float2 _1863 = _1165 * 8.0;
            float2 _1868 = fast::clamp(_2279, -_1863, _1863);
            float _2281;
            if (_1555 == _2302)
            {
                _2281 = 1.0 + _1486;
            }
            else
            {
                _2281 = _1486 - 2.0;
            }
            float _1901 = 1.0 - _1486;
            float2 _1910 = (((_1861 * smoothstep(0.5, 1.5, length(_1861 / _1165))) * 0.5) + ((_1868 * smoothstep(3.0, 6.0, length(_1868 / _1165))) * (_2281 * 0.16666667163372039794921875))) * (_1486 * _1901);
            float2 _1918 = (_1159 - (_1510 * _1486)) + _1910;
            float2 _1926 = (_1159 + (_1510 * _1901)) + _1910;
            float4 _2289;
            do
            {
                if (_1488)
                {
                    _2289 = _74.sample(_74Smplr, _1918, level(0.0));
                    break;
                }
                if (_2302 == 1)
                {
                    _2289 = _81.sample(_81Smplr, _1918, level(0.0));
                    break;
                }
                if (_2302 == 2)
                {
                    _2289 = _87.sample(_87Smplr, _1918, level(0.0));
                    break;
                }
                _2289 = _93.sample(_93Smplr, _1918, level(0.0));
                break;
            } while(false);
            float4 _2291;
            do
            {
                if (_1476 == 0)
                {
                    _2291 = _74.sample(_74Smplr, _1926, level(0.0));
                    break;
                }
                if (_1476 == 1)
                {
                    _2291 = _81.sample(_81Smplr, _1926, level(0.0));
                    break;
                }
                if (_1476 == 2)
                {
                    _2291 = _87.sample(_87Smplr, _1926, level(0.0));
                    break;
                }
                _2291 = _93.sample(_93Smplr, _1926, level(0.0));
                break;
            } while(false);
            _2295 = mix(_2289, _2291, float4(_1486));
            break;
        } while(false);
        _1343.write(_2295, uint2(_1126));
        break;
    } while(false);
}

