#pragma clang diagnostic ignored "-Wmissing-prototypes"
#pragma clang diagnostic ignored "-Wmissing-braces"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template<typename T, size_t Num>
struct spvUnsafeArray
{
    T elements[Num ? Num : 1];
    
    thread T& operator [] (size_t pos) thread
    {
        return elements[pos];
    }
    constexpr const thread T& operator [] (size_t pos) const thread
    {
        return elements[pos];
    }
    
    device T& operator [] (size_t pos) device
    {
        return elements[pos];
    }
    constexpr const device T& operator [] (size_t pos) const device
    {
        return elements[pos];
    }
    
    constexpr const constant T& operator [] (size_t pos) const constant
    {
        return elements[pos];
    }
    
    threadgroup T& operator [] (size_t pos) threadgroup
    {
        return elements[pos];
    }
    constexpr const threadgroup T& operator [] (size_t pos) const threadgroup
    {
        return elements[pos];
    }
};

// Implementation of signed integer mod accurate to SPIR-V specification
template<typename Tx, typename Ty>
inline Tx spvSMod(Tx x, Ty y)
{
    Tx remainder = x - y * (x / y);
    return select(Tx(remainder + y), remainder, remainder == 0 || (x >= 0) == (y >= 0));
}

// Returns the determinant of a 2x2 matrix.
static inline __attribute__((always_inline))
float spvDet2x2(float a1, float a2, float b1, float b2)
{
    return a1 * b2 - b1 * a2;
}

// Returns the inverse of a matrix, by using the algorithm of calculating the classical
// adjoint and dividing by the determinant. The contents of the matrix are changed.
static inline __attribute__((always_inline))
float3x3 spvInverse3x3(float3x3 m)
{
    float3x3 adj;	// The adjoint matrix (inverse after dividing by determinant)

    // Create the transpose of the cofactors, as the classical adjoint of the matrix.
    adj[0][0] =  spvDet2x2(m[1][1], m[1][2], m[2][1], m[2][2]);
    adj[0][1] = -spvDet2x2(m[0][1], m[0][2], m[2][1], m[2][2]);
    adj[0][2] =  spvDet2x2(m[0][1], m[0][2], m[1][1], m[1][2]);

    adj[1][0] = -spvDet2x2(m[1][0], m[1][2], m[2][0], m[2][2]);
    adj[1][1] =  spvDet2x2(m[0][0], m[0][2], m[2][0], m[2][2]);
    adj[1][2] = -spvDet2x2(m[0][0], m[0][2], m[1][0], m[1][2]);

    adj[2][0] =  spvDet2x2(m[1][0], m[1][1], m[2][0], m[2][1]);
    adj[2][1] = -spvDet2x2(m[0][0], m[0][1], m[2][0], m[2][1]);
    adj[2][2] =  spvDet2x2(m[0][0], m[0][1], m[1][0], m[1][1]);

    // Calculate the determinant as a combination of the cofactors of the first row.
    float det = (adj[0][0] * m[0][0]) + (adj[0][1] * m[1][0]) + (adj[0][2] * m[2][0]);

    // Divide the classical adjoint matrix by the determinant.
    // If determinant is zero, matrix is not invertable, so leave it unchanged.
    return (det != 0.0f) ? (adj * (1.0f / det)) : m;
}

struct _1148
{
    float2 _m0;
    float2 _m1;
    float2 _m2;
    float2 _m3;
    float2 _m4;
    float2 _m5;
    float2 _m6;
    float2 _m7;
    float2 _m8;
    float2 _m9;
    float2 _m10;
    float2 _m11;
    float2 _m12;
    float2 _m13;
    float2 _m14;
    float2 _m15;
    float2 _m16;
    float4 _m17[2];
    int _m18;
};

constant uint3 gl_WorkGroupSize [[maybe_unused]] = uint3(16u, 16u, 1u);

kernel void main0(constant _1148& _1150 [[buffer(17)]], texture2d<float> _74 [[texture(0)]], texture2d<float> _81 [[texture(1)]], texture2d<float> _87 [[texture(2)]], texture2d<float> _93 [[texture(3)]], texture2d<float> _99 [[texture(4)]], texture2d<float> _105 [[texture(5)]], texture2d<float> _111 [[texture(6)]], texture2d<float> _117 [[texture(7)]], texture2d<float> _123 [[texture(8)]], texture2d<float> _129 [[texture(9)]], texture2d<float> _135 [[texture(10)]], texture2d<float> _141 [[texture(11)]], texture2d<float> _147 [[texture(12)]], texture2d<float> _153 [[texture(13)]], texture2d<float> _159 [[texture(14)]], texture2d<float> _165 [[texture(15)]], texture2d<float, access::write> _1361 [[texture(16)]], sampler _74Smplr [[sampler(0)]], sampler _81Smplr [[sampler(1)]], sampler _87Smplr [[sampler(2)]], sampler _93Smplr [[sampler(3)]], sampler _99Smplr [[sampler(4)]], sampler _105Smplr [[sampler(5)]], sampler _111Smplr [[sampler(6)]], sampler _117Smplr [[sampler(7)]], sampler _123Smplr [[sampler(8)]], sampler _129Smplr [[sampler(9)]], sampler _135Smplr [[sampler(10)]], sampler _141Smplr [[sampler(11)]], sampler _147Smplr [[sampler(12)]], sampler _153Smplr [[sampler(13)]], sampler _159Smplr [[sampler(14)]], sampler _165Smplr [[sampler(15)]], uint3 gl_GlobalInvocationID [[thread_position_in_grid]])
{
    do
    {
        int2 _1144 = int2(gl_GlobalInvocationID.xy);
        bool _1155 = _1144.x >= int(_1150._m0.x);
        bool _1165;
        if (!_1155)
        {
            _1165 = _1144.y >= int(_1150._m0.y);
        }
        else
        {
            _1165 = _1155;
        }
        if (_1165)
        {
            break;
        }
        float2 _1177 = (float2(_1144) + float2(0.5)) / _1150._m0;
        float2 _1183 = float2(1.0) / _1150._m1;
        spvUnsafeArray<float, 8> _234;
        for (int _2267 = 0; _2267 < 8; )
        {
            _234[_2267] = _1150._m17[_2267 / 4][spvSMod(_2267, 4)];
            _2267++;
            continue;
        }
        float4 _2314;
        do
        {
            int _2321 = (_234[2] <= 0.0) ? 2 : int(_234[1] <= 0.0);
            int _1494 = _2321 + 1;
            float _1499 = _234[_1494] - _234[_2321];
            float _1504 = fast::clamp((-_234[_2321]) / _1499, 0.0, 1.0);
            bool _1506 = _2321 == 0;
            float2 _2271;
            if (_1506)
            {
                _2271 = _117.sample(_117Smplr, _1177, level(0.0)).xy;
            }
            else
            {
                float2 _2270;
                if (_2321 == 1)
                {
                    _2270 = _123.sample(_123Smplr, _1177, level(0.0)).xy;
                }
                else
                {
                    _2270 = _129.sample(_129Smplr, _1177, level(0.0)).xy;
                }
                _2271 = _2270;
            }
            float2 _1528 = (_2271 * 2.0) * _1183;
            float4 _1979 = _99.sample(_99Smplr, float2(0.5), level(0.0));
            float _1530 = _1979.x;
            float4 _1984 = _105.sample(_105Smplr, float2(0.5), level(0.0));
            float _1532 = _1984.x;
            float4 _1989 = _111.sample(_111Smplr, float2(0.5), level(0.0));
            float _1534 = _1989.x;
            float _2274;
            if (_1506)
            {
                _2274 = _1530;
            }
            else
            {
                _2274 = (_2321 == 1) ? _1532 : _1534;
            }
            if (_2274 > 0.125)
            {
                float4 _2313;
                if (_1504 < 0.5)
                {
                    float4 _2312;
                    do
                    {
                        if (_1506)
                        {
                            _2312 = _74.sample(_74Smplr, _1177, level(0.0));
                            break;
                        }
                        if (_2321 == 1)
                        {
                            _2312 = _81.sample(_81Smplr, _1177, level(0.0));
                            break;
                        }
                        if (_2321 == 2)
                        {
                            _2312 = _87.sample(_87Smplr, _1177, level(0.0));
                            break;
                        }
                        _2312 = _93.sample(_93Smplr, _1177, level(0.0));
                        break;
                    } while(false);
                    _2313 = _2312;
                }
                else
                {
                    float4 _2311;
                    do
                    {
                        if (_1494 == 0)
                        {
                            _2311 = _74.sample(_74Smplr, _1177, level(0.0));
                            break;
                        }
                        if (_1494 == 1)
                        {
                            _2311 = _81.sample(_81Smplr, _1177, level(0.0));
                            break;
                        }
                        if (_1494 == 2)
                        {
                            _2311 = _87.sample(_87Smplr, _1177, level(0.0));
                            break;
                        }
                        _2311 = _93.sample(_93Smplr, _1177, level(0.0));
                        break;
                    } while(false);
                    _2313 = _2311;
                }
                _2314 = _2313;
                break;
            }
            int _1573 = clamp((_1504 <= 0.5) ? _2321 : _1494, 1, 2);
            bool _1579 = _1573 == 1;
            float _2278;
            float _2279;
            float _2280;
            float2 _2281;
            float2 _2282;
            float2 _2283;
            float _2285;
            float _2287;
            float _2289;
            float _2293;
            if (_1579)
            {
                float2 _1675 = _141.sample(_141Smplr, _1177, level(0.0)).xy * _1183;
                float2 _1680 = _147.sample(_147Smplr, _1177, level(0.0)).xy * _1183;
                float2 _1683 = _1177 + _1680;
                float2 _1687 = _159.sample(_159Smplr, _1683, level(0.0)).xy * _1183;
                float2 _1690 = _1680 + _1687;
                float _1703 = length(_1183);
                float _1718 = length(_1680 + (_153.sample(_153Smplr, _1683, level(0.0)).xy * _1183)) / _1703;
                _2293 = fast::max(_1530, _1532);
                _2289 = fast::max(_1718, length(_1687 + (_165.sample(_165Smplr, (_1177 + _1690), level(0.0)).xy * _1183)) / _1703);
                _2287 = _1718;
                _2285 = length(_1675 + (_135.sample(_135Smplr, (_1177 + _1675), level(0.0)).xy * _1183)) / _1703;
                _2283 = _1690;
                _2282 = _1680;
                _2281 = _1675;
                _2280 = (_234[3] - _234[1]) / _1499;
                _2279 = (_234[2] - _234[1]) / _1499;
                _2278 = (_234[0] - _234[1]) / _1499;
            }
            else
            {
                float2 _1585 = _153.sample(_153Smplr, _1177, level(0.0)).xy * _1183;
                float2 _1590 = _159.sample(_159Smplr, _1177, level(0.0)).xy * _1183;
                float2 _1593 = _1177 + _1585;
                float2 _1597 = _141.sample(_141Smplr, _1593, level(0.0)).xy * _1183;
                float2 _1600 = _1585 + _1597;
                float _1613 = length(_1183);
                float _1614 = length(_1585 + (_147.sample(_147Smplr, _1593, level(0.0)).xy * _1183)) / _1613;
                _2293 = fast::max(_1532, _1534);
                _2289 = fast::max(_1614, length(_1597 + (_135.sample(_135Smplr, (_1177 + _1600), level(0.0)).xy * _1183)) / _1613);
                _2287 = length(_1590 + (_165.sample(_165Smplr, (_1177 + _1590), level(0.0)).xy * _1183)) / _1613;
                _2285 = _1614;
                _2283 = _1600;
                _2282 = _1590;
                _2281 = _1585;
                _2280 = (_234[0] - _234[2]) / _1499;
                _2279 = (_234[3] - _234[2]) / _1499;
                _2278 = (_234[1] - _234[2]) / _1499;
            }
            float _1768 = _2278 * _2278;
            float _1771 = _2279 * _2279;
            float _1774 = _2280 * _2280;
            float3x3 _1807 = float3x3(float3(_2278, _2279, _2280), float3(_1768, _1771, _1774) * 0.5, float3(_1768 * _2278, _1771 * _2279, _1774 * _2280) * float3(0.16666667163372039794921875));
            float2 _2290;
            float2 _2291;
            if (abs(determinant(_1807)) > 9.9999997473787516355514526367188e-05)
            {
                float3x3 _1814 = spvInverse3x3(_1807);
                float3 _1823 = _1814 * float3(_2281.x, _2282.x, _2283.x);
                float3 _1832 = _1814 * float3(_2281.y, _2282.y, _2283.y);
                _2291 = float2(_1823.z, _1832.z);
                _2290 = float2(_1823.y, _1832.y);
            }
            else
            {
                _2291 = float2(0.0);
                _2290 = float2(0.0);
            }
            float _1847 = fast::max(_2285, _2287);
            bool _1866 = _2293 > 0.125;
            float2 _2298;
            if (_1866)
            {
                _2298 = float2(0.0);
            }
            else
            {
                _2298 = select(_2291 * (1.0 - smoothstep(2.0, 5.0, fast::max(_1847, _2289))), float2(0.0), bool2((_1579 ? _1534 : _1530) > 0.125));
            }
            float2 _1875 = _1183 * 16.0;
            float2 _1880 = fast::clamp(select(_2290 * (1.0 - smoothstep(2.0, 5.0, _1847)), float2(0.0), bool2(_1866)), -_1875, _1875);
            float2 _1882 = _1183 * 8.0;
            float2 _1887 = fast::clamp(_2298, -_1882, _1882);
            float _2300;
            if (_1573 == _2321)
            {
                _2300 = 1.0 + _1504;
            }
            else
            {
                _2300 = _1504 - 2.0;
            }
            float _1920 = 1.0 - _1504;
            float2 _1929 = (((_1880 * smoothstep(0.5, 1.5, length(_1880 / _1183))) * 0.5) + ((_1887 * smoothstep(3.0, 6.0, length(_1887 / _1183))) * (_2300 * 0.16666667163372039794921875))) * (_1504 * _1920);
            float2 _1937 = (_1177 - (_1528 * _1504)) + _1929;
            float2 _1945 = (_1177 + (_1528 * _1920)) + _1929;
            float4 _2308;
            do
            {
                if (_1506)
                {
                    _2308 = _74.sample(_74Smplr, _1937, level(0.0));
                    break;
                }
                if (_2321 == 1)
                {
                    _2308 = _81.sample(_81Smplr, _1937, level(0.0));
                    break;
                }
                if (_2321 == 2)
                {
                    _2308 = _87.sample(_87Smplr, _1937, level(0.0));
                    break;
                }
                _2308 = _93.sample(_93Smplr, _1937, level(0.0));
                break;
            } while(false);
            float4 _2310;
            do
            {
                if (_1494 == 0)
                {
                    _2310 = _74.sample(_74Smplr, _1945, level(0.0));
                    break;
                }
                if (_1494 == 1)
                {
                    _2310 = _81.sample(_81Smplr, _1945, level(0.0));
                    break;
                }
                if (_1494 == 2)
                {
                    _2310 = _87.sample(_87Smplr, _1945, level(0.0));
                    break;
                }
                _2310 = _93.sample(_93Smplr, _1945, level(0.0));
                break;
            } while(false);
            _2314 = mix(_2308, _2310, float4(_1504));
            break;
        } while(false);
        _1361.write(_2314, uint2(_1144));
        break;
    } while(false);
}

